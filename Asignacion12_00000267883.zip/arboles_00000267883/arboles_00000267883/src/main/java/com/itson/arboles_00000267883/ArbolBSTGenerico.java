/*
 * Nombre del archivo: ArbolBSTGenerico.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Clase generica que implementa un Arbol Binario de Busqueda
 */
package com.itson.arboles_00000267883;

/**
 * Clase que implementa un Arbol Binario de Busqueda generico.
 * Puede almacenar cualquier tipo de dato que implemente Comparable.
 *
 * @param <T> El tipo de dato que almacena el árbol
 */
public class ArbolBSTGenerico<T extends Comparable<T>> {
    private NodoGenerico<T> raiz;

    /**
     * Constructor que inicializa un árbol vacío.
     */
    public ArbolBSTGenerico() {
        this.raiz = null;
    }

    /**
     * Inserta un nuevo valor en el árbol.
     * Si el valor ya existe, no se inserta y se muestra un mensaje.
     *
     * @param valor El valor a insertar
     */
    public void insertar(T valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    /**
     * Método recursivo auxiliar para insertar un valor en el árbol.
     *
     * @param nodo El nodo actual
     * @param valor El valor a insertar
     * @return El nodo actualizado
     */
    private NodoGenerico<T> insertarRecursivo(NodoGenerico<T> nodo, T valor) {
    // Si el arbol esta vacio, crear un nuevo nodo como raiz
        if (nodo == null) {
            return new NodoGenerico<>(valor);
        }

        // Comparar valores usando compareTo
        int comparacion = valor.compareTo(nodo.getValor());

        // Si el valor es menor, insertar en subárbol izquierdo
        if (comparacion < 0) {
            nodo.setIzquierdo(insertarRecursivo(nodo.getIzquierdo(), valor));
        }
        // Si el valor es mayor, insertar en subárbol derecho
        else if (comparacion > 0) {
            nodo.setDerecho(insertarRecursivo(nodo.getDerecho(), valor));
        }
        // Si el valor es igual, no insertar (valor duplicado)
        else {
            System.out.println("El valor " + valor + " ya existe en el arbol.");
        }

        return nodo;
    }

    /**
     * Busca un valor en el árbol.
     *
     * @param valor El valor a buscar
     * @return true si el valor existe, false en caso contrario
     */
    public boolean buscar(T valor) {
        return buscarRecursivo(raiz, valor);
    }

    /**
     * Método recursivo auxiliar para buscar un valor en el árbol.
     *
     * @param nodo El nodo actual
     * @param valor El valor a buscar
     * @return true si se encuentra, false en caso contrario
     */
    private boolean buscarRecursivo(NodoGenerico<T> nodo, T valor) {
        // Caso base: nodo es null, el valor no existe
        if (nodo == null) {
            return false;
        }

        int comparacion = valor.compareTo(nodo.getValor());

        // Si el valor coincide con el nodo actual
        if (comparacion == 0) {
            return true;
        }

        // Buscar recursivamente en el subárbol correspondiente
        if (comparacion < 0) {
            return buscarRecursivo(nodo.getIzquierdo(), valor);
        } else {
            return buscarRecursivo(nodo.getDerecho(), valor);
        }
    }

    /**
     * Realiza un recorrido inorden (Izq-Raíz-Der).
     * Imprime los valores en orden ascendente.
     */
    public void inorden() {
        inordenRecursivo(raiz);
    }

    /**
     * Método recursivo auxiliar para recorrido inorden.
     *
     * @param nodo El nodo actual
     */
    private void inordenRecursivo(NodoGenerico<T> nodo) {
        if (nodo != null) {
            // 1. Recorrer subárbol izquierdo
            inordenRecursivo(nodo.getIzquierdo());
            // 2. Visitar nodo actual
            System.out.println("  " + nodo.getValor());
            // 3. Recorrer subárbol derecho
            inordenRecursivo(nodo.getDerecho());
        }
    }

    /**
     * Encuentra el valor mínimo en el árbol.
     *
     * @return El valor mínimo
    * @throws IllegalStateException si el arbol esta vacio
     */
    public T encontrarMinimo() {
        if (raiz == null) {
            throw new IllegalStateException("El arbol esta vacio");
        }

        NodoGenerico<T> actual = raiz;
        // Ir siempre a la izquierda hasta encontrar el nodo sin hijo izquierdo
        while (actual.getIzquierdo() != null) {
            actual = actual.getIzquierdo();
        }
        return actual.getValor();
    }

    /**
     * Encuentra el valor máximo en el árbol.
     *
     * @return El valor máximo
     * @throws IllegalStateException si el árbol está vacío
     */
    public T encontrarMaximo() {
        if (raiz == null) {
            throw new IllegalStateException("El arbol esta vacío");
        }

        NodoGenerico<T> actual = raiz;
        // Ir siempre a la derecha hasta encontrar el nodo sin hijo derecho
        while (actual.getDerecho() != null) {
            actual = actual.getDerecho();
        }
        return actual.getValor();
    }

    /**
     * Cuenta el número total de nodos en el árbol.
     *
     * @return El número de nodos
     */
    public int contarNodos() {
        return contarNodosRecursivo(raiz);
    }

    /**
     * Método recursivo para contar nodos.
     *
     * @param nodo El nodo actual
     * @return El número de nodos en el subárbol
     */
    private int contarNodosRecursivo(NodoGenerico<T> nodo) {
        // Caso base: nodo vacío
        if (nodo == null) {
            return 0;
        }

        // Contar nodo actual + nodos de ambos subárboles
        return 1 + contarNodosRecursivo(nodo.getIzquierdo())
                 + contarNodosRecursivo(nodo.getDerecho());
    }

    /**
     * Calcula la suma de todos los valores en el árbol (para tipos numéricos).
     *
     * @param nodo El nodo actual
     * @return La suma acumulada
     */
    private double sumaRecursiva(NodoGenerico<T> nodo) {
        if (nodo == null) {
            return 0;
        }

        double valorActual = 0;
        // Intentar convertir el valor a número
        if (nodo.getValor() instanceof Number) {
            valorActual = ((Number) nodo.getValor()).doubleValue();
        }

        return valorActual + sumaRecursiva(nodo.getIzquierdo())
                           + sumaRecursiva(nodo.getDerecho());
    }

    /**
     * Calcula el promedio de todos los valores en el árbol.
     *
     * @return El promedio de los valores
     */
    public double calcularPromedio() {
        int totalNodos = contarNodos();
        if (totalNodos == 0) {
            return 0;
        }
        return sumaRecursiva(raiz) / totalNodos;
    }

    /**
     * Busca valores en un rango específico.
     *
     * @param min Valor mínimo del rango
     * @param max Valor máximo del rango
     */
    public void valoresEnRango(T min, T max) {
        valoresEnRangoRecursivo(raiz, min, max);
    }

    /**
     * Método recursivo para buscar valores en un rango.
     *
     * @param nodo El nodo actual
     * @param min Valor mínimo del rango
     * @param max Valor máximo del rango
     */
    private void valoresEnRangoRecursivo(NodoGenerico<T> nodo, T min, T max) {
        if (nodo == null) {
            return;
        }

        // Si el valor actual es mayor que min, explorar subárbol izquierdo
        if (nodo.getValor().compareTo(min) > 0) {
            valoresEnRangoRecursivo(nodo.getIzquierdo(), min, max);
        }

        // Si el valor actual está en el rango, imprimirlo
        if (nodo.getValor().compareTo(min) >= 0 && nodo.getValor().compareTo(max) <= 0) {
            System.out.println("  " + nodo.getValor());
        }

        // Si el valor actual es menor que max, explorar subárbol derecho
        if (nodo.getValor().compareTo(max) < 0) {
            valoresEnRangoRecursivo(nodo.getDerecho(), min, max);
        }
    }

    /**
     * Cuenta cuántos nodos cumplen con una condición basada en un valor umbral.
     *
     * @param umbral El valor umbral
     * @param mayorOIgual Si es true, cuenta los mayores o iguales; si es false, cuenta los menores
     * @return El número de nodos que cumplen la condición
     */
    public int contarPorCondicion(T umbral, boolean mayorOIgual) {
        return contarPorCondicionRecursivo(raiz, umbral, mayorOIgual);
    }

    /**
     * Método recursivo para contar nodos que cumplen una condición.
     *
     * @param nodo El nodo actual
     * @param umbral El valor umbral
     * @param mayorOIgual Si es true, cuenta los mayores o iguales
     * @return El número de nodos que cumplen la condición
     */
    private int contarPorCondicionRecursivo(NodoGenerico<T> nodo, T umbral, boolean mayorOIgual) {
        if (nodo == null) {
            return 0;
        }

        int contador = 0;
        int comparacion = nodo.getValor().compareTo(umbral);

        // Verificar si el nodo actual cumple la condición
        if ((mayorOIgual && comparacion >= 0) || (!mayorOIgual && comparacion < 0)) {
            contador = 1;
        }

        // Contar en ambos subárboles
        contador += contarPorCondicionRecursivo(nodo.getIzquierdo(), umbral, mayorOIgual);
        contador += contarPorCondicionRecursivo(nodo.getDerecho(), umbral, mayorOIgual);

        return contador;
    }

    /**
     * Verifica si el árbol está vacío.
     *
     * @return true si el árbol está vacío, false en caso contrario
     */
    public boolean esVacio() {
        return raiz == null;
    }

    /**
     * Obtiene la raíz del árbol (para testing).
     *
     * @return El nodo raíz
     */
    public NodoGenerico<T> getRaiz() {
        return raiz;
    }
}
