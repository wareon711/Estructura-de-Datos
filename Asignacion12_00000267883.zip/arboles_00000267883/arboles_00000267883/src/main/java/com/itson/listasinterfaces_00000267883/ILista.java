/*
 * Nombre del archivo: ILista.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Interfaz base para estructuras de datos tipo lista
 */

package com.itson.listasinterfaces_00000267883;

/**
 * Interfaz que define las operaciones b asicas de una lista.
 * Proporciona m etodos para agregar, eliminar, buscar y consultar elementos.
 *
 * @param <T> El tipo de elemento que almacena la lista
 */
public interface ILista<T> {

    /**
     * Agrega un elemento al final de la lista.
     *
     * @param elemento El elemento a agregar
     */
    void agregar(T elemento);

    /**
     * Agrega un elemento en una posición específica.
     *
     * @param indice La posición donde insertar el elemento
     * @param elemento El elemento a agregar
     * @throws IndexOutOfBoundsException si el índice está fuera de rango
     */
    void agregar(int indice, T elemento);

    /**
     * Elimina la primera ocurrencia del elemento especificado.
     *
     * @param elemento El elemento a eliminar
     * @return true si se eliminó el elemento, false si no se encontró
     */
    boolean eliminar(T elemento);

    /**
     * Elimina el elemento en la posición especificada.
     *
     * @param indice La posición del elemento a eliminar
     * @return El elemento eliminado
     * @throws IndexOutOfBoundsException si el índice está fuera de rango
     */
    T eliminar(int indice);

    /**
     * Obtiene el elemento en la posición especificada.
     *
     * @param indice La posición del elemento
     * @return El elemento en la posición especificada
     * @throws IndexOutOfBoundsException si el índice está fuera de rango
     */
    T obtener(int indice);

    /**
     * Busca un elemento en la lista.
     *
     * @param elemento El elemento a buscar
     * @return true si el elemento existe en la lista, false en caso contrario
     */
    boolean contiene(T elemento);

    /**
     * Obtiene el índice de la primera ocurrencia del elemento.
     *
     * @param elemento El elemento a buscar
     * @return El índice del elemento, o -1 si no se encuentra
     */
    int indiceDe(T elemento);

    /**
     * Retorna el número de elementos en la lista.
     *
     * @return El tamaño de la lista
     */
    int tamanio();

    /**
     * Verifica si la lista está vacía.
     *
     * @return true si la lista no tiene elementos, false en caso contrario
     */
    boolean estaVacia();

    /**
     * Elimina todos los elementos de la lista.
     */
    void limpiar();
}
