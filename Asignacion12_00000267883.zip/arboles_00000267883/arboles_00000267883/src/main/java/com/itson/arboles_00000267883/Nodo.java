/*
 * Nombre del archivo: Nodo.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Clase que representa un nodo en el arbol BST
 */
package com.itson.arboles_00000267883;

/**
 * Clase que representa un nodo en el arbol BST.
 * Cada nodo contiene un valor entero y referencias a sus hijos izquierdo y derecho.
 */
public class Nodo {
    private int valor;
    private Nodo izquierdo;
    private Nodo derecho;

    /**
     * Constructor que inicializa un nodo con un valor.
     * Los hijos izquierdo y derecho se inicializan como null.
     *
     * @param valor El valor entero a almacenar en el nodo
     */
    public Nodo(int valor) {
        this.valor = valor;
        this.izquierdo = null;
        this.derecho = null;
    }

    /**
     * Obtiene el valor almacenado en el nodo.
     *
     * @return El valor del nodo
     */
    public int getValor() {
        return valor;
    }

    /**
     * Establece el valor del nodo.
     *
     * @param valor El nuevo valor a almacenar
     */
    public void setValor(int valor) {
        this.valor = valor;
    }

    /**
     * Obtiene el hijo izquierdo del nodo.
     *
     * @return El nodo hijo izquierdo
     */
    public Nodo getIzquierdo() {
        return izquierdo;
    }

    /**
     * Establece el hijo izquierdo del nodo.
     *
     * @param izquierdo El nuevo nodo hijo izquierdo
     */
    public void setIzquierdo(Nodo izquierdo) {
        this.izquierdo = izquierdo;
    }

    /**
     * Obtiene el hijo derecho del nodo.
     *
     * @return El nodo hijo derecho
     */
    public Nodo getDerecho() {
        return derecho;
    }

    /**
     * Establece el hijo derecho del nodo.
     *
     * @param derecho El nuevo nodo hijo derecho
     */
    public void setDerecho(Nodo derecho) {
        this.derecho = derecho;
    }
}
