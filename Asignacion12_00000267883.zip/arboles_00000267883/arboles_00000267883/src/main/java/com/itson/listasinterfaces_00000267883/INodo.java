/*
 * Nombre del archivo: INodo.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Propósito: Interfaz para nodos de estructuras enlazadas
 */
package com.itson.listasinterfaces_00000267883;

/**
 * Interfaz que define un nodo en una estructura enlazada.
 *
 * @param <T> El tipo de dato que almacena el nodo
 */
public interface INodo<T> {

    /**
     * Obtiene el dato almacenado en el nodo.
     *
     * @return El dato del nodo
     */
    T getDato();

    /**
     * Establece el dato del nodo.
     *
     * @param dato El nuevo dato
     */
    void setDato(T dato);

    /**
     * Obtiene la referencia al siguiente nodo.
     *
     * @return El siguiente nodo
     */
    INodo<T> getSiguiente();

    /**
     * Establece la referencia al siguiente nodo.
     *
     * @param siguiente El nuevo nodo siguiente
     */
    void setSiguiente(INodo<T> siguiente);
}
