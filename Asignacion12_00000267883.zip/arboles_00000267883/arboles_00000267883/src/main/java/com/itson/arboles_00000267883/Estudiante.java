/*
 * Nombre del archivo: Estudiante.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Clase que representa un estudiante con su calificacion
 */
package com.itson.arboles_00000267883;

/**
 * Clase que representa un estudiante con su calificacion.
 * Implementa Comparable para poder ser utilizado en el arbol BST.
 */
public class Estudiante implements Comparable<Estudiante> {
    private String nombre;
    private int calificacion; // 0-100

    /**
     * Constructor que crea un estudiante con nombre y calificación.
     * Valida que la calificación esté en el rango correcto.
     *
     * @param nombre Nombre del estudiante
     * @param calificacion Calificación entre 0 y 100
     * @throws IllegalArgumentException si la calificación está fuera del rango
     */
    public Estudiante(String nombre, int calificacion) {
    if (calificacion < 0 || calificacion > 100) {
        throw new IllegalArgumentException(
            "Calificacion debe estar entre 0 y 100");
        }
        this.nombre = nombre;
        this.calificacion = calificacion;
    }

    /**
     * Obtiene el nombre del estudiante.
     *
     * @return El nombre del estudiante
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del estudiante.
     *
     * @param nombre El nuevo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la calificación del estudiante.
     *
     * @return La calificación del estudiante
     */
    public int getCalificacion() {
        return calificacion;
    }

    /**
     * Establece la calificación del estudiante.
     * Valida que esté en el rango correcto.
     *
     * @param calificacion La nueva calificación
     * @throws IllegalArgumentException si la calificación está fuera del rango
     */
    public void setCalificacion(int calificacion) {
    if (calificacion < 0 || calificacion > 100) {
        throw new IllegalArgumentException(
            "Calificacion debe estar entre 0 y 100");
        }
        this.calificacion = calificacion;
    }

    /**
     * Compara este estudiante con otro basándose en la calificación.
     *
     * @param otro El otro estudiante a comparar
     * @return Un valor negativo, cero o positivo si este estudiante tiene
     *         menor, igual o mayor calificación que el otro
     */
    @Override
    public int compareTo(Estudiante otro) {
        return Integer.compare(this.calificacion, otro.calificacion);
    }

    /**
     * Devuelve una representación en cadena del estudiante.
     *
     * @return Una cadena con el nombre y la calificación del estudiante
     */
    @Override
    public String toString() {
        return nombre + ": " + calificacion;
    }
}
