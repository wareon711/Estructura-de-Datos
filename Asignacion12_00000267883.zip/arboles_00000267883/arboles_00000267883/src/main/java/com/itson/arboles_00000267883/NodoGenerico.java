/*
 * Nombre del archivo: NodoGenerico.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Propósito: Clase genérica que representa un nodo en el árbol BST
 */
package com.itson.arboles_00000267883;

/**
 * Clase que representa un nodo genérico en el árbol BST.
 * Puede almacenar cualquier tipo de dato que implemente Comparable.
 *
 * @param <T> El tipo de dato que almacena el nodo
 */
public class NodoGenerico<T extends Comparable<T>> {
    private T valor;
    private NodoGenerico<T> izquierdo;
    private NodoGenerico<T> derecho;

    /**
     * Constructor que inicializa un nodo con un valor.
     * Los hijos izquierdo y derecho se inicializan como null.
     *
     * @param valor El valor a almacenar en el nodo
     */
    public NodoGenerico(T valor) {
        this.valor = valor;
        this.izquierdo = null;
        this.derecho = null;
    }

    /**
     * Obtiene el valor almacenado en el nodo.
     *
     * @return El valor del nodo
     */
    public T getValor() {
        return valor;
    }

    /**
     * Establece el valor del nodo.
     *
     * @param valor El nuevo valor a almacenar
     */
    public void setValor(T valor) {
        this.valor = valor;
    }

    /**
     * Obtiene el hijo izquierdo del nodo.
     *
     * @return El nodo hijo izquierdo
     */
    public NodoGenerico<T> getIzquierdo() {
        return izquierdo;
    }

    /**
     * Establece el hijo izquierdo del nodo.
     *
     * @param izquierdo El nuevo nodo hijo izquierdo
     */
    public void setIzquierdo(NodoGenerico<T> izquierdo) {
        this.izquierdo = izquierdo;
    }

    /**
     * Obtiene el hijo derecho del nodo.
     *
     * @return El nodo hijo derecho
     */
    public NodoGenerico<T> getDerecho() {
        return derecho;
    }

    /**
     * Establece el hijo derecho del nodo.
     *
     * @param derecho El nuevo nodo hijo derecho
     */
    public void setDerecho(NodoGenerico<T> derecho) {
        this.derecho = derecho;
    }
}
