/*
 * Nombre del archivo: ListaEnlazada.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Implementacion de una lista enlazada generica
 */
package com.itson.listasenlazadas_00000267883;

/**
 * Implementacion de una lista enlazada simple.
 *
 * @param <T> El tipo de dato que almacena la lista
 */
public class ListaEnlazada<T> {
    private Nodo<T> cabeza;
    private int tamanio;

    /**
     * Constructor que crea una lista vacía.
     */
    public ListaEnlazada() {
        this.cabeza = null;
        this.tamanio = 0;
    }

    /**
     * Agrega un elemento al final de la lista.
     *
     * @param dato El dato a agregar
     */
    public void agregar(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo<T> actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
        tamanio++;
    }

    /**
     * Obtiene el tamaño de la lista.
     *
     * @return El número de elementos
     */
    public int getTamanio() {
        return tamanio;
    }

    /**
     * Verifica si la lista está vacía.
     *
     * @return true si está vacía, false en caso contrario
     */
    public boolean estaVacia() {
        return cabeza == null;
    }
}
