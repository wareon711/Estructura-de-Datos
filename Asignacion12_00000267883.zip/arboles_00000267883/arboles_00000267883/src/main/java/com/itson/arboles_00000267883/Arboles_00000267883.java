/*
 * Nombre del archivo: Arboles_00000267883.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Clase principal que demuestra todas las funcionalidades del BST
 */

package com.itson.arboles_00000267883;

/**
 * Clase principal que contiene el metodo main.
 * Demuestra todas las funcionalidades del Arbol Binario de Busqueda.
 */
public class Arboles_00000267883 {

    public static void main(String[] args) {
    System.out.println("=================================");
    System.out.println("  DEMOSTRACION ARBOL BST");
    System.out.println("=================================\n");

    // PARTE 1: Pruebas basicas del BST
        pruebasBST();

    // PARTE 2: Sistema de gestion de estudiantes
        pruebaGestorEstudiantes();
    }

    /**
     * Metodo que realiza pruebas basicas del arbol BST.
     * Demuestra insercion, busqueda, recorridos, eliminacion y consultas.
     */
    private static void pruebasBST() {
        System.out.println("--- PRUEBAS BST BASICO ---\n");

        ArbolBST arbol = new ArbolBST();

        // Insertar valores
        System.out.println("Insertando valores: 50, 30, 70, 20, 40, 60, 80");
        int[] valores = {50, 30, 70, 20, 40, 60, 80};
        for (int valor : valores) {
            arbol.insertar(valor);
        }

        // Intentar insertar un valor duplicado
        System.out.println("\nIntentando insertar valor duplicado (50):");
        arbol.insertar(50);

        // Mostrar recorridos
        System.out.println("\nRECORRIDOS:");
        arbol.inorden();
        arbol.preorden();
        arbol.postorden();

    // Busquedas
    System.out.println("\nBUSQUEDAS:");
        System.out.println("Buscar 40: " + arbol.buscar(40));
        System.out.println("Buscar 100: " + arbol.buscar(100));

    // Informacion del arbol
    System.out.println("\nINFORMACION DEL ARBOL:");
        System.out.println("Altura: " + arbol.altura());
        System.out.println("Total nodos: " + arbol.contarNodos());
    System.out.println("Minimo: " + arbol.encontrarMinimo());
    System.out.println("Maximo: " + arbol.encontrarMaximo());
        // PARTE 1: Pruebas basicas del BST
        // PARTE 2: Sistema de gestion de estudiantes
    // Eliminaciones
    System.out.println("\nELIMINACIONES:");
    System.out.println("Eliminando 20 (sin hijos - hoja)...");
        arbol.eliminar(20);
        arbol.inorden();
        System.out.println("Nueva altura: " + arbol.altura());
        System.out.println("Nuevos nodos: " + arbol.contarNodos());

    System.out.println("\nEliminando 30 (con dos hijos)...");
        arbol.eliminar(30);
        arbol.inorden();
        System.out.println("Nueva altura: " + arbol.altura());
        System.out.println("Nuevos nodos: " + arbol.contarNodos());

    System.out.println("\nEliminando 50 (raiz)...");
        arbol.eliminar(50);
        arbol.inorden();
        System.out.println("Nueva altura: " + arbol.altura());
        System.out.println("Nuevos nodos: " + arbol.contarNodos());
        System.out.println("Nuevo mínimo: " + arbol.encontrarMinimo());
        System.out.println("Nuevo máximo: " + arbol.encontrarMaximo());
    }

    /**
     * Metodo que realiza pruebas del sistema de gestion de estudiantes.
     * Demuestra el uso practico del BST con objetos personalizados.
     */
    private static void pruebaGestorEstudiantes() {
        System.out.println("\n\n--- SISTEMA GESTOR DE ESTUDIANTES ---\n");

        GestorEstudiantes gestor = new GestorEstudiantes();

        // Agregar estudiantes
        System.out.println("=== Agregando estudiantes ===");
        gestor.agregarEstudiante("Ana Garcia", 95);
        gestor.agregarEstudiante("Carlos Lopez", 78);
        gestor.agregarEstudiante("Maria Rodriguez", 88);
        gestor.agregarEstudiante("Juan Martinez", 65);
        gestor.agregarEstudiante("Laura Sanchez", 92);
        gestor.agregarEstudiante("Pedro Gomez", 58);
        gestor.agregarEstudiante("Sofia Torres", 85);

        // Mostrar todos los estudiantes ordenados por calificacion
        gestor.mostrarEstudiantes();

        // Estudiantes en un rango especifico
        gestor.estudiantesEnRango(80, 95);

        // Estudiantes en otro rango
        gestor.estudiantesEnRango(60, 75);

        // Estadisticas
        System.out.println("\n=== ESTADISTICAS ===");
        System.out.println("Total de estudiantes: " + gestor.totalEstudiantes());
        System.out.printf("Promedio de calificaciones: %.2f\n", gestor.promedioCalificaciones());
        System.out.println("Mejor estudiante: " + gestor.mejorEstudiante());
        System.out.println("Estudiante con menor calificacion: " + gestor.peorEstudiante());
        System.out.println("Estudiantes aprobados (>= 70): " + gestor.contarAprobados());
        System.out.println("Estudiantes reprobados (< 70): " + gestor.contarReprobados());

        // Demostracion adicional: Agregar mas estudiantes
        System.out.println("\n=== Agregando mas estudiantes ===");
        gestor.agregarEstudiante("Roberto Diaz", 100);
        gestor.agregarEstudiante("Carmen Flores", 45);
        gestor.agregarEstudiante("Diego Morales", 70);

        // Mostrar actualizacion
        gestor.mostrarEstudiantes();

        // Estadisticas actualizadas
        System.out.println("\n=== ESTADISTICAS ACTUALIZADAS ===");
        System.out.println("Total de estudiantes: " + gestor.totalEstudiantes());
        System.out.printf("Promedio de calificaciones: %.2f\n", gestor.promedioCalificaciones());
        System.out.println("Mejor estudiante: " + gestor.mejorEstudiante());
        System.out.println("Estudiante con menor calificacion: " + gestor.peorEstudiante());
        System.out.println("Estudiantes aprobados (>= 70): " + gestor.contarAprobados());
        System.out.println("Estudiantes reprobados (< 70): " + gestor.contarReprobados());

        System.out.println("\n=================================");
        System.out.println("  FIN DE LA DEMOSTRACION");
        System.out.println("=================================");
    }
}
