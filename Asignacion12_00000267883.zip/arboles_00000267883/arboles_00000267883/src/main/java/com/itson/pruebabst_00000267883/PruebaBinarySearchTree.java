/*
 * Nombre del archivo: PruebaBinarySearchTree.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Propósito: Clase de prueba adicional para el BST con Integer y String
 *           (Módulo separado que representa pruebaBinarySearchTree_ID)
 */

package com.itson.pruebabst_00000267883;

// Importar las clases del módulo principal
import com.itson.arboles_00000267883.ArbolBSTGenerico;

/**
 * Clase de prueba que demuestra el uso del BST con diferentes tipos de datos.
 * Incluye pruebas con Integer y String para cumplir con los requisitos.
 *
 * Este módulo representa el "proyecto pruebaBinarySearchTree_ID" requerido.
 *
 */
public class PruebaBinarySearchTree {

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("  PRUEBAS BINARY SEARCH TREE");
        System.out.println("  Módulo: pruebaBinarySearchTree_00000267883");
        System.out.println("  ID: 00000267883");
        System.out.println("=========================================\n");

        // Pruebas con Integer
        pruebasConInteger();

        // Pruebas con String
        pruebasConString();
    }

    /**
     * Realiza pruebas completas del BST con tipo Integer.
     */
    private static void pruebasConInteger() {
    System.out.println("\n========================================");
    System.out.println("  PRUEBAS CON ARBOL DE ENTEROS");
    System.out.println("========================================\n");

        // a) Crea un árbol binario de búsqueda de enteros vacío
        System.out.println("a) Creando árbol binario de búsqueda de enteros vacío...");
        ArbolBSTGenerico<Integer> arbolEnteros = new ArbolBSTGenerico<>();
    System.out.println("   ARBOL creado. Esta vacio? " + arbolEnteros.esVacio());

        // b) Agrega enteros al árbol
        System.out.println("\nb) Agregando enteros al árbol...");
        int[] numeros = {50, 25, 75, 10, 30, 60, 80, 5, 15, 27, 35};
        for (int num : numeros) {
            arbolEnteros.insertar(num);
                System.out.println("   Insertado: " + num);
        }
        System.out.println("   Total de nodos: " + arbolEnteros.contarNodos());

        // c) Muestre el contenido del árbol
        System.out.println("\nc) Mostrando el contenido del árbol (Inorden):");
        arbolEnteros.inorden();

        // d) Obtiene el dato menor del árbol
        System.out.println("\nd) Obteniendo el dato menor del árbol:");
        Integer menor = arbolEnteros.encontrarMinimo();
    System.out.println("   Valor minimo: " + menor);

        // e) Obtiene el dato mayor del árbol
        System.out.println("\ne) Obteniendo el dato mayor del árbol:");
        Integer mayor = arbolEnteros.encontrarMaximo();
    System.out.println("   Valor maximo: " + mayor);

        // f) Obtiene un dato del árbol (búsqueda)
        System.out.println("\nf) Buscando datos en el árbol:");
        Integer[] busquedas = {30, 27, 100, 5};
        for (Integer valor : busquedas) {
            boolean encontrado = arbolEnteros.buscar(valor);
            System.out.println("   Buscar " + valor + ": " +
                             (encontrado ? "ENCONTRADO" : "NO ENCONTRADO"));
        }

        // g) Modifique un dato del árbol (eliminar e insertar)
        System.out.println("\ng) Modificando datos del árbol:");
        System.out.println("   Agregando nuevo valor 32...");
        arbolEnteros.insertar(32);
    System.out.println("   Nuevo valor agregado");

        System.out.println("\n   Contenido actualizado del árbol:");
        arbolEnteros.inorden();

        // Información adicional
    System.out.println("\nINFORMACION ADICIONAL DEL ARBOL DE ENTEROS:");
    System.out.println("   Total de nodos: " + arbolEnteros.contarNodos());
    System.out.println("   Valor minimo: " + arbolEnteros.encontrarMinimo());
    System.out.println("   Valor maximo: " + arbolEnteros.encontrarMaximo());
    System.out.println("   Promedio: " + String.format("%.2f",
              arbolEnteros.calcularPromedio()));
    }

    /**
     * Realiza pruebas completas del BST con tipo String.
     */
    private static void pruebasConString() {
    System.out.println("\n\n========================================");
    System.out.println("  PRUEBAS CON ARBOL DE CADENAS");
    System.out.println("========================================\n");

        // h) Crea un árbol binario de búsqueda de cadenas vacío
        System.out.println("h) Creando árbol binario de búsqueda de cadenas vacío...");
        ArbolBSTGenerico<String> arbolCadenas = new ArbolBSTGenerico<>();
    System.out.println("   ARBOL creado. Esta vacio? " + arbolCadenas.esVacio());

        // i) Agrega cadenas al árbol
        System.out.println("\ni) Agregando cadenas al árbol...");
        String[] palabras = {"manzana", "banana", "pera", "uva", "kiwi",
                            "naranja", "sandia", "melon", "fresa", "durazno"};
        for (String palabra : palabras) {
            arbolCadenas.insertar(palabra);
            System.out.println("   Insertado: " + palabra);
        }
    System.out.println("   Total de nodos: " + arbolCadenas.contarNodos());

        // j) Muestre el contenido del árbol
        System.out.println("\nj) Mostrando el contenido del árbol (orden alfabético):");
        arbolCadenas.inorden();

        // k) Obtiene el dato menor del árbol
        System.out.println("\nk) Obteniendo el dato menor del árbol:");
        String menorCadena = arbolCadenas.encontrarMinimo();
    System.out.println("   Primera cadena alfabeticamente: " + menorCadena);

        // l) Obtiene el dato mayor del árbol
        System.out.println("\nl) Obteniendo el dato mayor del árbol:");
        String mayorCadena = arbolCadenas.encontrarMaximo();
    System.out.println("   Ultima cadena alfabeticamente: " + mayorCadena);

        // m) Obtiene un dato del árbol (búsqueda)
        System.out.println("\nm) Buscando datos en el árbol:");
        String[] busquedasCadenas = {"pera", "manzana", "limon", "kiwi"};
        for (String palabra : busquedasCadenas) {
            boolean encontrado = arbolCadenas.buscar(palabra);
            System.out.println("   Buscar \"" + palabra + "\": " +
                             (encontrado ? "ENCONTRADO" : "NO ENCONTRADO"));
        }

        // n) Modifique un dato del árbol (eliminar conceptualmente y agregar)
        System.out.println("\nn) Modificando datos del árbol:");
        System.out.println("   Agregando 'cereza' como nueva fruta...");
        arbolCadenas.insertar("cereza");
    System.out.println("   Nueva fruta agregada");

        System.out.println("\n   Contenido actualizado del árbol:");
        arbolCadenas.inorden();

        // Información adicional
    System.out.println("\nINFORMACION ADICIONAL DEL ARBOL DE CADENAS:");
    System.out.println("   Total de palabras: " + arbolCadenas.contarNodos());
    System.out.println("   Primera alfabeticamente: " + arbolCadenas.encontrarMinimo());
    System.out.println("   Ultima alfabeticamente: " + arbolCadenas.encontrarMaximo());

        // Demostración de búsqueda en rango
    System.out.println("\nBUSQUEDA EN RANGO (de 'f' a 'p'):");
    arbolCadenas.valoresEnRango("f", "p");

    System.out.println("\n=========================================");
    System.out.println("  TODAS LAS PRUEBAS COMPLETADAS");
    System.out.println("  Modulo: com.itson.pruebabst");
    System.out.println("=========================================");
    }
}
