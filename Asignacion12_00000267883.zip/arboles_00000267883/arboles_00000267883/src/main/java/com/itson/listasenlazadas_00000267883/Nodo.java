/*
 * Nombre del archivo: Nodo.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Propósito: Implementación de un nodo para lista enlazada
 */
package com.itson.listasenlazadas_00000267883;

/**
 * Clase que representa un nodo en una lista enlazada.
 *
 * @param <T> El tipo de dato que almacena el nodo
 */
public class Nodo<T> {
    private T dato;
    private Nodo<T> siguiente;

    /**
     * Constructor que crea un nodo con un dato.
     *
     * @param dato El dato a almacenar
     */
    public Nodo(T dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    /**
     * Obtiene el dato del nodo.
     *
     * @return El dato almacenado
     */
    public T getDato() {
        return dato;
    }

    /**
     * Establece el dato del nodo.
     *
     * @param dato El nuevo dato
     */
    public void setDato(T dato) {
        this.dato = dato;
    }

    /**
     * Obtiene el siguiente nodo.
     *
     * @return El siguiente nodo
     */
    public Nodo<T> getSiguiente() {
        return siguiente;
    }

    /**
     * Establece el siguiente nodo.
     *
     * @param siguiente El nuevo nodo siguiente
     */
    public void setSiguiente(Nodo<T> siguiente) {
        this.siguiente = siguiente;
    }
}
