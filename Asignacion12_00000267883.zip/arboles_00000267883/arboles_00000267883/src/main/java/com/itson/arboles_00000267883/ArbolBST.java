/*
 * Nombre del archivo: ArbolBST.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Clase que implementa un Arbol Binario de Busqueda
 */
package com.itson.arboles_00000267883;

/**
 * Clase que implementa un Arbol Binario de Busqueda.
 * Proporciona operaciones de insercion, busqueda, eliminacion y recorridos.
 *
 */
public class ArbolBST {
    private Nodo raiz;

    /**
    * Constructor que inicializa un arbol vacio.
     */
    public ArbolBST() {
        this.raiz = null;
    }

    /**
    * Inserta un nuevo valor en el arbol.
     * Si el valor ya existe, no se inserta y se muestra un mensaje.
     *
     * @param valor El valor a insertar
     */
    public void insertar(int valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    /**
     * Método recursivo auxiliar para insertar un valor en el árbol.
     *
     * @param nodo El nodo actual
     * @param valor El valor a insertar
     * @return El nodo actualizado
     */
    private Nodo insertarRecursivo(Nodo nodo, int valor) {
    // Si el arbol esta vacio, crear un nuevo nodo como raiz
        if (nodo == null) {
            return new Nodo(valor);
        }

    // Si el valor es menor, insertar en subarbol izquierdo
        if (valor < nodo.getValor()) {
            nodo.setIzquierdo(insertarRecursivo(nodo.getIzquierdo(), valor));
        }
    // Si el valor es mayor, insertar en subarbol derecho
        else if (valor > nodo.getValor()) {
            nodo.setDerecho(insertarRecursivo(nodo.getDerecho(), valor));
        }
        // Si el valor es igual, no insertar (valor duplicado)
        else {
            System.out.println("El valor " + valor + " ya existe en el arbol.");
        }

        return nodo;
    }

    /**
    * Busca un valor en el arbol.
     *
     * @param valor El valor a buscar
     * @return true si el valor existe, false en caso contrario
     */
    public boolean buscar(int valor) {
        return buscarRecursivo(raiz, valor);
    }

    /**
     * Método recursivo auxiliar para buscar un valor en el árbol.
     *
     * @param nodo El nodo actual
     * @param valor El valor a buscar
     * @return true si se encuentra, false en caso contrario
     */
    private boolean buscarRecursivo(Nodo nodo, int valor) {
        // Caso base: nodo es null, el valor no existe
        if (nodo == null) {
            return false;
        }

        // Si el valor coincide con el nodo actual
        if (valor == nodo.getValor()) {
            return true;
        }

    // Buscar recursivamente en el subarbol correspondiente
        if (valor < nodo.getValor()) {
            return buscarRecursivo(nodo.getIzquierdo(), valor);
        } else {
            return buscarRecursivo(nodo.getDerecho(), valor);
        }
    }

    /**
    * Elimina un valor del arbol.
     *
     * @param valor El valor a eliminar
     */
    public void eliminar(int valor) {
        raiz = eliminarRecursivo(raiz, valor);
    }

    /**
     * Método recursivo auxiliar para eliminar un valor del árbol.
     * Maneja tres casos: nodo sin hijos, nodo con un hijo, nodo con dos hijos.
     *
     * @param nodo El nodo actual
     * @param valor El valor a eliminar
     * @return El nodo actualizado
     */
    private Nodo eliminarRecursivo(Nodo nodo, int valor) {
    // Caso 1: Arbol vacio
    if (nodo == null) {
            return null;
        }

        // Buscar el nodo a eliminar
        if (valor < nodo.getValor()) {
            // Buscar en subarbol izquierdo
            nodo.setIzquierdo(eliminarRecursivo(nodo.getIzquierdo(), valor));
        } else if (valor > nodo.getValor()) {
            // Buscar en subarbol derecho
            nodo.setDerecho(eliminarRecursivo(nodo.getDerecho(), valor));
        } else {
            // Nodo encontrado - manejar los 3 casos

            // Caso 2: Nodo sin hijos (hoja)
            if (nodo.getIzquierdo() == null && nodo.getDerecho() == null) {
                return null;
            }

            // Caso 3: Nodo con un solo hijo
            if (nodo.getIzquierdo() == null) {
                return nodo.getDerecho();
            }
            if (nodo.getDerecho() == null) {
                return nodo.getIzquierdo();
            }

            // Caso 4: Nodo con dos hijos
            // Encontrar el sucesor inorden (minimo del subarbol derecho)
            int minimoValor = encontrarMinimoValor(nodo.getDerecho());
            // Reemplazar el valor del nodo con el sucesor
            nodo.setValor(minimoValor);
            // Eliminar el sucesor del subárbol derecho
            nodo.setDerecho(eliminarRecursivo(nodo.getDerecho(), minimoValor));
        }

        return nodo;
    }

    /**
     * Encuentra el valor mínimo en un subárbol.
     *
     * @param nodo La raíz del subárbol
     * @return El valor mínimo
     */
    private int encontrarMinimoValor(Nodo nodo) {
        int minimo = nodo.getValor();
        while (nodo.getIzquierdo() != null) {
            minimo = nodo.getIzquierdo().getValor();
            nodo = nodo.getIzquierdo();
        }
        return minimo;
    }

    /**
     * Realiza un recorrido inorden (Izq-Raíz-Der).
     * Imprime los valores en orden ascendente.
     */
    public void inorden() {
        System.out.print("Recorrido Inorden: ");
        inordenRecursivo(raiz);
        System.out.println();
    }

    /**
     * Método recursivo auxiliar para recorrido inorden.
     *
     * @param nodo El nodo actual
     */
    private void inordenRecursivo(Nodo nodo) {
        if (nodo != null) {
            // 1. Recorrer subárbol izquierdo
            inordenRecursivo(nodo.getIzquierdo());
            // 2. Visitar nodo actual
            System.out.print(nodo.getValor() + " ");
            // 3. Recorrer subárbol derecho
            inordenRecursivo(nodo.getDerecho());
        }
    }

    /**
     * Realiza un recorrido preorden (Raíz-Izq-Der).
     * Útil para copiar el árbol.
     */
    public void preorden() {
        System.out.print("Recorrido Preorden: ");
        preordenRecursivo(raiz);
        System.out.println();
    }

    /**
     * Método recursivo auxiliar para recorrido preorden.
     *
     * @param nodo El nodo actual
     */
    private void preordenRecursivo(Nodo nodo) {
        if (nodo != null) {
            // 1. Visitar nodo actual
            System.out.print(nodo.getValor() + " ");
            // 2. Recorrer subárbol izquierdo
            preordenRecursivo(nodo.getIzquierdo());
            // 3. Recorrer subárbol derecho
            preordenRecursivo(nodo.getDerecho());
        }
    }

    /**
     * Realiza un recorrido postorden (Izq-Der-Raíz).
     * Útil para eliminar el árbol.
     */
    public void postorden() {
        System.out.print("Recorrido Postorden: ");
        postordenRecursivo(raiz);
        System.out.println();
    }

    /**
     * Método recursivo auxiliar para recorrido postorden.
     *
     * @param nodo El nodo actual
     */
    private void postordenRecursivo(Nodo nodo) {
        if (nodo != null) {
            // 1. Recorrer subárbol izquierdo
            postordenRecursivo(nodo.getIzquierdo());
            // 2. Recorrer subárbol derecho
            postordenRecursivo(nodo.getDerecho());
            // 3. Visitar nodo actual
            System.out.print(nodo.getValor() + " ");
        }
    }

    /**
     * Calcula la altura del árbol.
     * La altura es el número de aristas en el camino más largo desde la raíz hasta una hoja.
     *
     * @return La altura del árbol (-1 si está vacío, 0 si solo tiene raíz)
     */
    public int altura() {
        return alturaRecursiva(raiz);
    }

    /**
     * Método recursivo auxiliar para calcular la altura.
     *
     * @param nodo El nodo actual
     * @return La altura del subárbol
     */
    private int alturaRecursiva(Nodo nodo) {
        // Caso base: árbol vacío
        if (nodo == null) {
            return -1;
        }

        // Calcular altura de los subárboles
        int alturaIzq = alturaRecursiva(nodo.getIzquierdo());
        int alturaDer = alturaRecursiva(nodo.getDerecho());

        // La altura es el máximo de las dos alturas más 1
        return Math.max(alturaIzq, alturaDer) + 1;
    }

    /**
     * Cuenta el número total de nodos en el árbol.
     *
     * @return El número de nodos
     */
    public int contarNodos() {
        return contarNodosRecursivo(raiz);
    }

    /**
     * Método recursivo para contar nodos.
     *
     * @param nodo El nodo actual
     * @return El número de nodos en el subárbol
     */
    private int contarNodosRecursivo(Nodo nodo) {
        // Caso base: nodo vacío
        if (nodo == null) {
            return 0;
        }

        // Contar nodo actual + nodos de ambos subárboles
        return 1 + contarNodosRecursivo(nodo.getIzquierdo())
                 + contarNodosRecursivo(nodo.getDerecho());
    }

    /**
     * Encuentra el valor mínimo en el árbol.
     *
     * @return El valor mínimo
    * @throws IllegalStateException si el arbol esta vacio
     */
    public int encontrarMinimo() {
        if (raiz == null) {
            throw new IllegalStateException("El arbol esta vacio");
        }

        Nodo actual = raiz;
        // Ir siempre a la izquierda hasta encontrar el nodo sin hijo izquierdo
        while (actual.getIzquierdo() != null) {
            actual = actual.getIzquierdo();
        }
        return actual.getValor();
    }

    /**
     * Encuentra el valor máximo en el árbol.
     *
     * @return El valor máximo
    * @throws IllegalStateException si el arbol esta vacio
     */
    public int encontrarMaximo() {
        if (raiz == null) {
            throw new IllegalStateException("El arbol esta vacio");
        }

        Nodo actual = raiz;
        // Ir siempre a la derecha hasta encontrar el nodo sin hijo derecho
        while (actual.getDerecho() != null) {
            actual = actual.getDerecho();
        }
        return actual.getValor();
    }

    /**
     * Verifica si el árbol está vacío.
     *
     * @return true si el árbol está vacío, false en caso contrario
     */
    public boolean esVacio() {
        return raiz == null;
    }

    /**
     * Obtiene la raíz del árbol (para testing).
     *
     * @return El nodo raíz
     */
    public Nodo getRaiz() {
        return raiz;
    }
}
