/*
 * Nombre del archivo: GestorEstudiantes.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * ID: 00000267883, 00000267850, 00000260176
 * Proposito: Gestor que utiliza un BST para organizar estudiantes por calificacion
 */
package com.itson.arboles_00000267883;

/**
 * Gestor que utiliza un BST para organizar estudiantes por calificacion.
 * Proporciona metodos para agregar, buscar y analizar estudiantes.
 */
public class GestorEstudiantes {
    private ArbolBSTGenerico<Estudiante> arbol;

    /**
    * Constructor que inicializa el gestor con un arbol BST vacio.
     */
    public GestorEstudiantes() {
        arbol = new ArbolBSTGenerico<>();
    }

    /**
     * Agrega un estudiante al sistema.
     *
     * @param nombre Nombre del estudiante
     * @param calificacion Calificación del estudiante (0-100)
     */
    public void agregarEstudiante(String nombre, int calificacion) {
        Estudiante estudiante = new Estudiante(nombre, calificacion);
        arbol.insertar(estudiante);
        System.out.println("Estudiante agregado: " + estudiante);
    }

    /**
    * Muestra todos los estudiantes ordenados por calificacion.
     */
    public void mostrarEstudiantes() {
    System.out.println("\n=== Estudiantes ordenados por calificacion ===");
        if (arbol.esVacio()) {
            System.out.println("No hay estudiantes registrados.");
        } else {
            arbol.inorden();
        }
    }

    /**
     * Encuentra estudiantes en un rango de calificaciones.
     *
     * @param min Calificación mínima
     * @param max Calificación máxima
     */
    public void estudiantesEnRango(int min, int max) {
    System.out.println("\nEstudiantes con calificacion entre " + min + " y " + max + ":");

        if (arbol.esVacio()) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }

        // Crear estudiantes dummy para el rango
        Estudiante estudianteMin = new Estudiante("", min);
        Estudiante estudianteMax = new Estudiante("", max);

        arbol.valoresEnRango(estudianteMin, estudianteMax);
    }

    /**
     * Calcula el promedio de todas las calificaciones.
     *
     * @return El promedio de las calificaciones
     */
    public double promedioCalificaciones() {
        if (arbol.esVacio()) {
            return 0.0;
        }
        return arbol.calcularPromedio();
    }

    /**
     * Encuentra al estudiante con la mejor calificación.
     *
     * @return El estudiante con mejor calificación
     * @throws IllegalStateException si no hay estudiantes
     */
    public Estudiante mejorEstudiante() {
        if (arbol.esVacio()) {
            throw new IllegalStateException("No hay estudiantes registrados.");
        }
        return arbol.encontrarMaximo();
    }

    /**
     * Encuentra al estudiante con la calificación más baja.
     *
     * @return El estudiante con la calificación más baja
     * @throws IllegalStateException si no hay estudiantes
     */
    public Estudiante peorEstudiante() {
        if (arbol.esVacio()) {
            throw new IllegalStateException("No hay estudiantes registrados.");
        }
        return arbol.encontrarMinimo();
    }

    /**
     * Cuenta cuántos estudiantes aprobaron (>= 70).
     *
     * @return Número de estudiantes aprobados
     */
    public int contarAprobados() {
        if (arbol.esVacio()) {
            return 0;
        }
        // Crear un estudiante dummy con calificación 70
        Estudiante umbral = new Estudiante("", 70);
        return arbol.contarPorCondicion(umbral, true);
    }

    /**
     * Cuenta cuántos estudiantes reprobaron (< 70).
     *
     * @return Número de estudiantes reprobados
     */
    public int contarReprobados() {
        if (arbol.esVacio()) {
            return 0;
        }
        // Crear un estudiante dummy con calificación 70
        Estudiante umbral = new Estudiante("", 70);
        return arbol.contarPorCondicion(umbral, false);
    }

    /**
     * Obtiene el número total de estudiantes.
     *
     * @return El número total de estudiantes
     */
    public int totalEstudiantes() {
        return arbol.contarNodos();
    }
}
