package Ejercicios;

/*
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

/*
 * Implementacion de una Cola (Queue) usando nodos enlazados.
 * Sigue el principio FIFO: el primer elemento en entrar es el primero en salir.
 * @param <T> Tipo de dato que almacenara la cola
 */
public class Cola<T> {
    private Nodo<T> frente;  // Primer elemento de la cola
    private Nodo<T> fin;     // Ultimo elemento de la cola
    private int tamanio;     // Cantidad de elementos

    /**
     * Crea una cola vacia
     */
    public Cola() {
        this.frente = null;
        this.fin = null;
        this.tamanio = 0;
    }

    /**
     * Agrega un elemento al final de la cola
     * @param dato Elemento a agregar
     */
    public void encolar(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        if (estaVacia()) {
            // Si la cola esta vacia, el nuevo nodo es tanto frente como fin
            frente = nuevoNodo;
            fin = nuevoNodo;
        } else {
            // Si ya hay elementos, agregamos al final
            fin.setSiguiente(nuevoNodo);
            fin = nuevoNodo;
        }
        tamanio++;
    }

    /**
     * Elimina y retorna el primer elemento de la cola
     * @return El elemento del frente
     * @throws RuntimeException si la cola esta vacia
     */
    public T desencolar() {
        if (estaVacia()) {
            throw new RuntimeException("La cola esta vacia");
        }
        T dato = frente.getDato();
        frente = frente.getSiguiente();
        // Si eliminamos el ultimo elemento, el fin tambien debe ser null
        if (frente == null) {
            fin = null;
        }
        tamanio--;
        return dato;
    }

    /**
     * Consulta el primer elemento sin eliminarlo de la cola
     * @return El elemento del frente
     * @throws RuntimeException si la cola esta vacia
     */
    public T verFrente() {
        if (estaVacia()) {
            throw new RuntimeException("La cola esta vacia");
        }
        return frente.getDato();
    }

    /**
     * Verifica si la cola esta vacia
     * @return true si esta vacia, false en caso contrario
     */
    public boolean estaVacia() {
        return frente == null;
    }

    /**
     * Retorna el tamanio de la cola
     * @return Numero de elementos en la cola
     */
    public int getTamanio() {
        return tamanio;
    }
}
