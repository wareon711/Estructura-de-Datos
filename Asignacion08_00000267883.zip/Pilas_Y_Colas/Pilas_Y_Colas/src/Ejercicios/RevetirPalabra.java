package Ejercicios;

/*
  Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/*
  Ejercicio 1: Revertir caracteres de una palabra
  Usa una PILA porque necesitamos invertir el orden de los caracteres.
  Al apilar cada letra y luego desapilarlas, obtenemos la palabra al reves.
  Principio LIFO: el ultimo caracter apilado es el primero en salir.
 */
public class RevetirPalabra {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pila<Character> pila = new Pila<>();

        System.out.println("=== REVERTIR PALABRA ===");
        System.out.print("Ingrese una palabra: ");
        String palabra = scanner.nextLine();

        // Apilamos cada caracter de la palabra
        for (int i = 0; i < palabra.length(); i++) {
            pila.apilar(palabra.charAt(i));
        }

        // Al desapilar obtenemos los caracteres en orden inverso
        System.out.print("Palabra invertida: ");
        while (!pila.estaVacia()) {
            System.out.print(pila.desapilar());
        }
        System.out.println();

        scanner.close();
    }

}
