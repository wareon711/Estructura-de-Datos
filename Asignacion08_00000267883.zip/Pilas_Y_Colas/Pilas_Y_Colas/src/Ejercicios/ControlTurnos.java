package Ejercicios;

/*
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/**
 * Ejercicio 2: Sistema de control de turnos
 *
 * Usa una COLA porque los turnos se atienden por orden de llegada.
 * El primero en solicitar turno es el primero en ser atendido.
 * Principio FIFO: simula una fila real de personas esperando su turno.
 */
public class ControlTurnos {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cola<Integer> colaTurnos = new Cola<>();
        int numeroTurno = 1;  // Contador para asignar turnos
        int opcion;

        System.out.println("=== CONTROL DE TURNOS ===");

        do {
            System.out.println("\n1. Asignar turno");
            System.out.println("2. Atender siguiente turno");
            System.out.println("3. Ver siguiente en turno");
            System.out.println("4. Mostrar turnos pendientes");
            System.out.println("5. Salir");
            System.out.print("Elija una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Asignamos un nuevo turno y lo agregamos al final de la cola
                    colaTurnos.encolar(numeroTurno);
                    System.out.println("Turno asignado: " + numeroTurno);
                    numeroTurno++;
                    break;

                case 2:
                    // Atendemos al primer turno en la cola
                    if (!colaTurnos.estaVacia()) {
                        int turnoAtendido = colaTurnos.desencolar();
                        System.out.println("Atendiendo turno: " + turnoAtendido);
                    } else {
                        System.out.println("No hay turnos pendientes");
                    }
                    break;

                case 3:
                    if (!colaTurnos.estaVacia()) {
                        System.out.println("Siguiente turno: " + colaTurnos.verFrente());
                    } else {
                        System.out.println("No hay turnos pendientes");
                    }
                    break;

                case 4:
                    if (colaTurnos.estaVacia()) {
                        System.out.println("No hay turnos pendientes");
                    } else {
                        System.out.println("Turnos pendientes: " + colaTurnos.getTamanio());
                    }
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }
        } while (opcion != 5);

        scanner.close();
    }

}
