package Ejercicios;

/*
  Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/**
   Ejercicio 6: Sistema de juego por turnos

   Usa una COLA para rotar los turnos de manera circular.
   Cada jugador juega su turno y vuelve al final de la cola.
   Principio FIFO circular: simula juegos como Monopoly o cartas.
 */
public class JuegoPorTurnos {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cola<String> colaJugadores = new Cola<>();
        int opcion;

        System.out.println("=== JUEGO POR TURNOS ===");

        do {
            System.out.println("\n1. Agregar jugador");
            System.out.println("2. Jugar turno (pasar al siguiente)");
            System.out.println("3. Ver jugador actual");
            System.out.println("4. Ver cantidad de jugadores");
            System.out.println("5. Salir");
            System.out.print("Elija una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiamos el buffer del scanner

            switch (opcion) {
                case 1:
                    // Agregamos un nuevo jugador al juego
                    System.out.print("Nombre del jugador: ");
                    String nombre = scanner.nextLine();
                    colaJugadores.encolar(nombre);
                    System.out.println("Jugador agregado al juego");
                    break;

                case 2:
                    if (!colaJugadores.estaVacia()) {
                        // El jugador actual juega y vuelve al final de la cola
                        String jugadorActual = colaJugadores.desencolar();
                        System.out.println("Turno de: " + jugadorActual);
                        System.out.println(jugadorActual + " jugo su turno");
                        colaJugadores.encolar(jugadorActual); // Rotacion circular

                        if (!colaJugadores.estaVacia()) {
                            System.out.println("Siguiente turno: " + colaJugadores.verFrente());
                        }
                    } else {
                        System.out.println("No hay jugadores en el juego");
                    }
                    break;

                case 3:
                    if (!colaJugadores.estaVacia()) {
                        System.out.println("Jugador actual: " + colaJugadores.verFrente());
                    } else {
                        System.out.println("No hay jugadores en el juego");
                    }
                    break;

                case 4:
                    if (colaJugadores.estaVacia()) {
                        System.out.println("No hay jugadores en el juego");
                    } else {
                        System.out.println("Jugadores en el juego: " + colaJugadores.getTamanio());
                    }
                    break;

                case 5:
                    System.out.println("Saliendo del juego...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }
        } while (opcion != 5);

        scanner.close();
    }

}
