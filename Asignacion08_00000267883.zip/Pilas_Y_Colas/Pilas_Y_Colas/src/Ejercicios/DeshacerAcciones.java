package Ejercicios;

/*
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/**
 * Ejercicio 3: Editor de texto con funcion deshacer
 *
 * Usa una PILA para implementar la funcion "Ctrl+Z" o deshacer.
 * Cada palabra escrita se apila, y al deshacer se elimina la ultima palabra.
 * Principio LIFO: deshacemos desde la accion mas reciente hacia atras.
 */
public class DeshacerAcciones {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pila<String> pilaAcciones = new Pila<>();
        int opcion;

        System.out.println("=== EDITOR CON DESHACER ===");

        do {
            System.out.println("\n1. Escribir palabra");
            System.out.println("2. Deshacer ultima palabra");
            System.out.println("3. Mostrar texto actual");
            System.out.println("4. Salir");
            System.out.print("Elija una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiamos el buffer del scanner

            switch (opcion) {
                case 1:
                    // Agregamos una nueva palabra al editor
                    System.out.print("Ingrese palabra: ");
                    String palabra = scanner.nextLine();
                    pilaAcciones.apilar(palabra);
                    System.out.println("Palabra agregada");
                    break;

                case 2:
                    // Deshacemos la ultima palabra escrita
                    if (!pilaAcciones.estaVacia()) {
                        String palabraEliminada = pilaAcciones.desapilar();
                        System.out.println("Palabra eliminada: " + palabraEliminada);
                    } else {
                        System.out.println("No hay acciones para deshacer");
                    }
                    break;

                case 3:
                    if (pilaAcciones.estaVacia()) {
                        System.out.println("Texto actual: (vacio)");
                    } else {
                        // Mostrar el texto usando una pila auxiliar
                        Pila<String> pilaAux = new Pila<>();
                        System.out.print("Texto actual: ");

                        // Pasar a pila auxiliar para mantener orden
                        while (!pilaAcciones.estaVacia()) {
                            pilaAux.apilar(pilaAcciones.desapilar());
                        }

                        // Mostrar y devolver a la pila original
                        boolean primero = true;
                        while (!pilaAux.estaVacia()) {
                            String palabraActual = pilaAux.desapilar();
                            if (!primero) System.out.print(" ");
                            System.out.print(palabraActual);
                            pilaAcciones.apilar(palabraActual);
                            primero = false;
                        }
                        System.out.println();
                    }
                    break;

                case 4:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }
        } while (opcion != 4);

        scanner.close();
    }

}
