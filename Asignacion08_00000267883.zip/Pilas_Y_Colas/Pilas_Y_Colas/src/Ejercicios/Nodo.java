package Ejercicios;

/*
   Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

/*
   Clase Nodo generica para construir estructuras de datos enlazadas.
   Cada nodo contiene un dato y una referencia al siguiente nodo.
   @param <T> Tipo de dato que almacenara el nodo
 */
public class Nodo<T> {
    private T dato;              // Informacion almacenada en el nodo
    private Nodo<T> siguiente;   // Referencia al siguiente nodo

    /**
       Crea un nuevo nodo con el dato especificado
       @param dato Informacion a almacenar en el nodo
     */
    public Nodo(T dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    // Getters y setters

    public T getDato() {
        return dato;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

    public Nodo<T> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo<T> siguiente) {
        this.siguiente = siguiente;
    }
}
