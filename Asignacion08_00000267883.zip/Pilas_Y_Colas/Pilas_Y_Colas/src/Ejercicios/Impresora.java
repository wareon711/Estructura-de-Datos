package Ejercicios;

/*
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/**
 * Ejercicio 4: Sistema de cola de impresion
 *
 * Usa una COLA porque los documentos se imprimen en orden de llegada.
 * El primer documento enviado es el primero que sale de la impresora.
 * Principio FIFO: simula una impresora real procesando trabajos.
 */
public class Impresora {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cola<String> colaImpresion = new Cola<>();
        int opcion;

        System.out.println("=== COLA DE IMPRESIÓN ===");

        do {
            System.out.println("\n1. Agregar documento a la cola");
            System.out.println("2. Imprimir siguiente documento");
            System.out.println("3. Ver siguiente documento");
            System.out.println("4. Ver documentos pendientes");
            System.out.println("5. Salir");
            System.out.print("Elija una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiamos el buffer del scanner

            switch (opcion) {
                case 1:
                    // Enviamos un documento a la cola de impresion
                    System.out.print("Nombre del documento: ");
                    String documento = scanner.nextLine();
                    colaImpresion.encolar(documento);
                    System.out.println("Documento agregado a la cola");
                    break;

                case 2:
                    // Imprimimos el primer documento en la cola
                    if (!colaImpresion.estaVacia()) {
                        String docImpreso = colaImpresion.desencolar();
                        System.out.println("Imprimiendo: " + docImpreso);
                        System.out.println("Documento impreso exitosamente");
                    } else {
                        System.out.println("No hay documentos en la cola");
                    }
                    break;

                case 3:
                    if (!colaImpresion.estaVacia()) {
                        System.out.println("Siguiente documento: " + colaImpresion.verFrente());
                    } else {
                        System.out.println("No hay documentos en la cola");
                    }
                    break;

                case 4:
                    if (colaImpresion.estaVacia()) {
                        System.out.println("No hay documentos pendientes");
                    } else {
                        System.out.println("Documentos pendientes: " + colaImpresion.getTamanio());
                    }
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion invalida");
            }
        } while (opcion != 5);

        scanner.close();
    }

}
