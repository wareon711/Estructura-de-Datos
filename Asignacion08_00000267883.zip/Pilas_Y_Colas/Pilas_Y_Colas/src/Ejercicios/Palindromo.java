package Ejercicios;

/*
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

import java.util.Scanner;

/*
  Ejercicio 5: Verificador de palindromos
  Usa una PILA para invertir la palabra y verificar si es palindromo.
  Un palindromo se lee igual de izquierda a derecha que de derecha a izquierda.
  Ejemplos: "oso", "anilina", "reconocer".
 */
public class Palindromo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== VERIFICADOR DE PALINDROMOS ===");
        System.out.print("Ingrese una palabra: ");
        String palabra = scanner.nextLine().toLowerCase();

        // Usamos una pila para invertir la palabra
        Pila<Character> pila = new Pila<>();

        // Apilamos cada caracter de la palabra
        for (int i = 0; i < palabra.length(); i++) {
            pila.apilar(palabra.charAt(i));
        }

        // Construimos la palabra invertida desapilando
        StringBuilder palabraInvertida = new StringBuilder();
        while (!pila.estaVacia()) {
            palabraInvertida.append(pila.desapilar());
        }

        // Si la palabra es igual a su inversa, es palindromo
        if (palabra.equals(palabraInvertida.toString())) {
            System.out.println("SI es palindromo");
        } else {
            System.out.println("NO es palindromo");
        }

        System.out.println("Palabra original: " + palabra);
        System.out.println("Palabra invertida: " + palabraInvertida);

        scanner.close();
    }

}
