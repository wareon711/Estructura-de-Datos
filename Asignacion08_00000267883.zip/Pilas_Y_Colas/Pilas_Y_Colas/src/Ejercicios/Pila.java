package Ejercicios;

/*
  Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 */

/*
   Implementacion de una Pila (Stack) usando nodos enlazados.
   Sigue el principio LIFO: el ultimo elemento en entrar es el primero en salir.
   @param <T> Tipo de dato que almacenara la pila
 */
public class Pila<T> {
    private Nodo<T> tope;    // Elemento en la cima de la pila
    private int tamanio;     // Cantidad de elementos

    /*
       Crea una pila vacia
     */
    public Pila() {
        this.tope = null;
        this.tamanio = 0;
    }

    /*
       Agrega un elemento en la cima de la pila
       @param dato Elemento a agregar
     */
    public void apilar(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        // El nuevo nodo apunta al tope actual
        nuevoNodo.setSiguiente(tope);
        // El nuevo nodo se convierte en el tope
        tope = nuevoNodo;
        tamanio++;
    }

    /*
       Elimina y retorna el elemento de la cima de la pila
       @return El elemento del tope
       @throws RuntimeException si la pila esta vacia
     */
    public T desapilar() {
        if (estaVacia()) {
            throw new RuntimeException("La pila esta vacia");
        }
        T dato = tope.getDato();
        tope = tope.getSiguiente();
        tamanio--;
        return dato;
    }

    /*
     Consulta el elemento de la cima sin eliminarlo
     @return El elemento del tope
     @throws RuntimeException si la pila esta vacia
     */
    public T verTope() {
        if (estaVacia()) {
            throw new RuntimeException("La pila esta vacia");
        }
        return tope.getDato();
    }

    /*
       Verifica si la pila esta vacia
       @return true si esta vacia, false en caso contrario
     */
    public boolean estaVacia() {
        return tope == null;
    }

    /*
       Retorna el tamanio de la pila
       @return Numero de elementos en la pila
     */
    public int getTamanio() {
        return tamanio;
    }
}
