package com.itson.funcionesrecursivas;

import java.io.File;

/**
 * Clase que contiene ejercicios de programacion recursiva e iterativa.
 * Cada ejercicio esta implementado en dos versiones: iterativa y recursiva,
 * con comentarios detallados indicando el caso base y el caso recursivo.
 * Esta clase es parte de la tarea de Estructura de Datos sobre recursividad.
 *
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Córdova
 *
 * @version 1.0
 */
public class RecursionExercises {

    // ============================================
    // EJERCICIO 1: Suma de elementos de un arreglo
    // ============================================

    /**
     * Version ITERATIVA: Suma de elementos de un arreglo.
     * Recorre el arreglo con un bucle acumulando la suma de todos los elementos.
     *
     * @param arr El arreglo de enteros a sumar.
     * @return La suma total de los elementos del arreglo.
     * @example sumaIterativa([1, 2, 3]) retorna 6
     */
    public static int sumaIterativa(int[] arr) {
        int suma = 0;
        for (int i = 0; i < arr.length; i++) {
            suma += arr[i];
        }
        return suma;
    }

    /**
     * Version RECURSIVA: Suma de elementos de un arreglo.
     * CASO BASE: Si el indice esta fuera del rango del arreglo (index >= arr.length), retorna 0.
     * CASO RECURSIVO: Suma el elemento actual (arr[index]) con la suma del resto del arreglo.
     *
     * @param arr El arreglo de enteros a sumar.
     * @param index El indice actual desde donde empezar la suma.
     * @return La suma total de los elementos desde el indice dado hasta el final.
     * @example sumaRecursiva([1, 2, 3], 0) retorna 6
     */
    public static int sumaRecursiva(int[] arr, int index) {
        // CASO BASE: si el indice esta fuera de rango
        if (index >= arr.length) {
            return 0;
        }
        // CASO RECURSIVO: elemento actual + suma del resto
        return arr[index] + sumaRecursiva(arr, index + 1);
    }

    /**
     * Sobrecarga para facilitar la llamada a sumaRecursiva, empezando desde el indice 0.
     *
     * @param arr El arreglo de enteros a sumar.
     * @return La suma total de todos los elementos del arreglo.
     */
    public static int sumaRecursiva(int[] arr) {
        return sumaRecursiva(arr, 0);
    }


    // ============================================
    // EJERCICIO 2: Contar ocurrencias
    // ============================================

    /**
     * Version ITERATIVA: Contar ocurrencias de un valor x en un arreglo.
     * Recorre el arreglo con un bucle contando cuantas veces aparece x.
     *
     * @param arr El arreglo de enteros donde buscar.
     * @param x El valor a contar.
     * @return El numero de veces que x aparece en el arreglo.
     * @example contarIterativo([1, 2, 2, 3], 2) retorna 2
     */
    public static int contarIterativo(int[] arr, int x) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == x) {
                count++;
            }
        }
        return count;
    }

    /**
     * Version RECURSIVA: Contar ocurrencias de un valor x en un arreglo.
     * CASO BASE: Si el indice esta fuera del rango (index >= arr.length), retorna 0.
     * CASO RECURSIVO: Si el elemento actual es igual a x, suma 1; de lo contrario, suma 0;
     *                 mas el conteo del resto del arreglo.
     *
     * @param arr El arreglo de enteros donde buscar.
     * @param x El valor a contar.
     * @param index El indice actual desde donde empezar el conteo.
     * @return El numero de veces que x aparece desde el indice dado hasta el final.
     * @example contarRecursivo([1, 2, 2, 3], 2, 0) retorna 2
     */
    public static int contarRecursivo(int[] arr, int x, int index) {
        // CASO BASE: indice fuera de rango
        if (index >= arr.length) {
            return 0;
        }
        // CASO RECURSIVO: suma 1 si coincide, 0 si no + recursion en el resto
        int coincide = (arr[index] == x) ? 1 : 0;
        return coincide + contarRecursivo(arr, x, index + 1);
    }

    /**
     * Sobrecarga para facilitar la llamada a contarRecursivo, empezando desde el indice 0.
     *
     * @param arr El arreglo de enteros donde buscar.
     * @param x El valor a contar.
     * @return El numero total de veces que x aparece en el arreglo.
     */
    public static int contarRecursivo(int[] arr, int x) {
        return contarRecursivo(arr, x, 0);
    }


    // ============================================
    // EJERCICIO 3: Imprimir archivos y carpetas
    // ============================================

    /**
     * Version ITERATIVA: Exploracion de directorios usando una pila.
     * Simula la recursion con una pila para listar archivos y carpetas jerarquicamente.
     *
     * @param rutaInicial La ruta del directorio raiz a explorar.
     */
    public static void listarArchivosIterativo(String rutaInicial) {
        java.util.Stack<File> pila = new java.util.Stack<>();
        java.util.Stack<Integer> niveles = new java.util.Stack<>();

        File raiz = new File(rutaInicial);
        pila.push(raiz);
        niveles.push(0);

        while (!pila.isEmpty()) {
            File actual = pila.pop();
            int nivel = niveles.pop();

            // Imprimir con indentacion segun el nivel
            String indent = "  ".repeat(nivel);
            if (actual.isDirectory()) {
                System.out.println(indent + "[DIR] " + actual.getName());

                // Agregar hijos a la pila
                File[] hijos = actual.listFiles();
                if (hijos != null) {
                    for (int i = hijos.length - 1; i >= 0; i--) {
                        pila.push(hijos[i]);
                        niveles.push(nivel + 1);
                    }
                }
            } else {
                System.out.println(indent + "[FILE] " + actual.getName());
            }
        }
    }

    /**
     * Version RECURSIVA: Exploracion de directorios.
     * CASO BASE: Si el elemento no es un directorio (es un archivo), imprime el archivo.
     * CASO RECURSIVO: Si es un directorio, imprime el directorio y procesa recursivamente cada hijo.
     *
     * @param archivo El archivo o directorio actual a procesar.
     * @param nivel El nivel de profundidad para la indentacion.
     */
    public static void listarArchivosRecursivo(File archivo, int nivel) {
        // Indentacion segun el nivel de profundidad
        String indent = "  ".repeat(nivel);

        if (archivo.isDirectory()) {
            // Es un directorio
            System.out.println(indent + "[DIR] " + archivo.getName());

            // CASO RECURSIVO: procesar cada hijo
            File[] hijos = archivo.listFiles();
            if (hijos != null) {
                for (File hijo : hijos) {
                    listarArchivosRecursivo(hijo, nivel + 1);
                }
            }
        } else {
            // CASO BASE: es un archivo (no hay mas recursion)
            System.out.println(indent + "[FILE] " + archivo.getName());
        }
    }

    /**
     * Sobrecarga para facilitar la llamada a listarArchivosRecursivo, empezando desde nivel 0.
     *
     * @param ruta La ruta del directorio raiz a explorar.
     */
    public static void listarArchivosRecursivo(String ruta) {
        listarArchivosRecursivo(new File(ruta), 0);
    }


    // ============================================
    // EJERCICIO 4: Invertir una cadena
    // ============================================

    /**
     * Version ITERATIVA: Invertir una cadena.
     * Recorre la cadena de atras hacia adelante construyendo la cadena invertida.
     *
     * @param s La cadena a invertir.
     * @return La cadena invertida.
     * @example invertirIterativo("hola") retorna "aloh"
     */
    public static String invertirIterativo(String s) {
        StringBuilder resultado = new StringBuilder();
        for (int i = s.length() - 1; i >= 0; i--) {
            resultado.append(s.charAt(i));
        }
        return resultado.toString();
    }

    /**
     * Version RECURSIVA: Invertir una cadena.
     * CASO BASE: Si la cadena esta vacia o tiene un solo caracter, retorna la misma cadena.
     * CASO RECURSIVO: Toma el ultimo caracter y lo concatena con la inversion del resto.
     *
     * @param s La cadena a invertir.
     * @return La cadena invertida.
     * @example invertirRecursivo("hola") retorna "aloh"
     */
    public static String invertirRecursivo(String s) {
        // CASO BASE: cadena vacia o de un solo caracter
        if (s.length() <= 1) {
            return s;
        }
        // CASO RECURSIVO: ultimo caracter + invertir el resto (sin el ultimo)
        return s.charAt(s.length() - 1) + invertirRecursivo(s.substring(0, s.length() - 1));
    }


    // ============================================
    // EJERCICIO 5: Numero palindromo
    // ============================================

    /**
     * Version ITERATIVA: Verificar si un numero es palindromo.
     * Convierte el numero a cadena y compara los digitos desde ambos extremos hacia el centro.
     *
     * @param numero El numero entero a verificar.
     * @return true si es palindromo, false en caso contrario.
     * @example esPalindromoIterativo(12321) retorna true
     */
    public static boolean esPalindromoIterativo(int numero) {
        String s = String.valueOf(Math.abs(numero));
        int inicio = 0;
        int fin = s.length() - 1;

        while (inicio < fin) {
            if (s.charAt(inicio) != s.charAt(fin)) {
                return false;
            }
            inicio++;
            fin--;
        }
        return true;
    }

    /**
     * Version RECURSIVA: Verificar si una cadena representa un numero palindromo.
     * CASO BASE: Si los indices se cruzan (inicio >= fin), es palindromo.
     * CASO RECURSIVO: Si los extremos coinciden, verifica recursivamente el interior.
     *
     * @param s La cadena que representa el numero.
     * @param inicio El indice de inicio para comparar.
     * @param fin El indice de fin para comparar.
     * @return true si es palindromo, false en caso contrario.
     */
    public static boolean esPalindromoRecursivo(String s, int inicio, int fin) {
        // CASO BASE: se cruzaron los indices o son iguales (toda la cadena verificada)
        if (inicio >= fin) {
            return true;
        }
        // Si los extremos no coinciden, no es palindromo
        if (s.charAt(inicio) != s.charAt(fin)) {
            return false;
        }
        // CASO RECURSIVO: extremos coinciden, verificar el interior
        return esPalindromoRecursivo(s, inicio + 1, fin - 1);
    }

    /**
     * Sobrecarga para facilitar la llamada a esPalindromoRecursivo con un numero entero.
     *
     * @param numero El numero entero a verificar.
     * @return true si es palindromo, false en caso contrario.
     */
    public static boolean esPalindromoRecursivo(int numero) {
        String s = String.valueOf(Math.abs(numero));
        return esPalindromoRecursivo(s, 0, s.length() - 1);
    }


    // ============================================
    // METODO MAIN PARA PRUEBAS
    // ============================================

    /**
     * Metodo principal que ejecuta pruebas para todos los ejercicios.
     * Imprime los resultados de cada version iterativa y recursiva.
     *
     * @param args Argumentos de linea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        System.out.println("=== EJERCICIO 1: SUMA DE ARREGLO ===");
        int[] arr1 = {4, 2, 7, 1};
        System.out.println("Arreglo: [4, 2, 7, 1]");
        System.out.println("Suma Iterativa: " + sumaIterativa(arr1));
        System.out.println("Suma Recursiva: " + sumaRecursiva(arr1));

        System.out.println("\n=== EJERCICIO 2: CONTAR OCURRENCIAS ===");
        int[] arr2 = {2, 4, 2, 8, 2, 3};
        int x = 2;
        System.out.println("Arreglo: [2, 4, 2, 8, 2, 3], buscar: 2");
        System.out.println("Contar Iterativo: " + contarIterativo(arr2, x));
        System.out.println("Contar Recursivo: " + contarRecursivo(arr2, x));

        System.out.println("\n=== EJERCICIO 3: LISTAR ARCHIVOS ===");
        System.out.println("(Descomentar y proporcionar una ruta valida para probar)");
        System.out.println("\n--- LISTADO (ITERATIVO) ---");
        listarArchivosIterativo(".");
        System.out.println("\n--- LISTADO (RECURSIVO) ---");
        listarArchivosRecursivo(".");

        System.out.println("\n=== EJERCICIO 4: INVERTIR CADENA ===");
        String cadena = "hola";
        System.out.println("Cadena original: " + cadena);
        System.out.println("Invertir Iterativo: " + invertirIterativo(cadena));
        System.out.println("Invertir Recursivo: " + invertirRecursivo(cadena));

        System.out.println("\n=== EJERCICIO 5: PALINDROMO ===");
        int num1 = 12321;
        System.out.println("Numero: " + num1);
        System.out.println("Es palindromo (Iterativo): " + esPalindromoIterativo(num1));
        System.out.println("Es palindromo (Recursivo): " + esPalindromoRecursivo(num1));
    }
}
