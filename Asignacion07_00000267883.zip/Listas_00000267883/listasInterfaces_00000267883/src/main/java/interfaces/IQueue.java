package interfaces;

import excepciones.QueueException;

/**
 * Archivo: IQueue.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Interfaz generica que define las operaciones basicas de una cola (Queue)
 *
 * Esta interfaz define los metodos que debe implementar cualquier clase
 * que represente una cola con comportamiento FIFO (First In, First Out).
 * Una cola permite agregar elementos al final y extraerlos desde el frente.
 */
public interface IQueue<T> {

    /**
     * Agrega un elemento al final de la cola (enqueue)
     * @param element El elemento a agregar
     * @throws QueueException si la cola está llena
     */
    void enqueue(T element) throws QueueException;

    /**
     * Extrae y retorna el elemento al frente de la cola (dequeue)
     * @return El elemento que estaba al frente de la cola
     * @throws QueueException si la cola está vacía
     */
    T dequeue() throws QueueException;

    /**
     * Retorna el elemento al frente de la cola sin extraerlo (peek)
     * @return El elemento al frente de la cola
     * @throws QueueException si la cola está vacía
     */
    T peek() throws QueueException;

    /**
     * Verifica si la cola está vacía
     * @return true si la cola está vacía, false en caso contrario
     */
    boolean isEmpty();

    /**
     * Obtiene el número de elementos en la cola
     * @return El tamaño actual de la cola
     */
    int size();

    /**
     * Elimina todos los elementos de la cola
     */
    void clear();
}
