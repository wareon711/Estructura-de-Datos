package interfaces;

import excepciones.ListException;

/**
 * Archivo: IDoubleList.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Interfaz generica que define las operaciones de una lista doblemente enlazada
 *
 * Esta interfaz extiende IList y agrega metodos especificos para listas doblemente enlazadas,
 * como la busqueda del ultimo indice y eliminacion de la ultima ocurrencia.
 */
public interface IDoubleList<T> extends IList<T> {

    /**
     * Obtiene el índice de la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a buscar
     * @return El índice de la última ocurrencia del elemento o -1 si no se encuentra
     */
    int lastIndexOf(T o);

    /**
     * Elimina la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a eliminar
     * @return true si el elemento fue encontrado y eliminado, false en caso contrario
     * @throws ListException si la lista está vacía
     */
    boolean removeLast(T o) throws ListException;
}
