package interfaces;

import excepciones.StackException;

/**
 * Archivo: IStack.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Interfaz generica que define las operaciones basicas de una pila (Stack)
 *
 * Esta interfaz define los metodos que debe implementar cualquier clase
 * que represente una pila con comportamiento LIFO (Last In, First Out).
 * Una pila permite agregar elementos en la cima y extraerlos en orden inverso.
 */
public interface IStack<T> {

    /**
     * Agrega un elemento en la cima de la pila (push)
     * @param element El elemento a agregar
     * @throws StackException si la pila está llena
     */
    void push(T element) throws StackException;

    /**
     * Extrae y retorna el elemento en la cima de la pila (pop)
     * @return El elemento que estaba en la cima de la pila
     * @throws StackException si la pila está vacía
     */
    T pop() throws StackException;

    /**
     * Retorna el elemento en la cima de la pila sin extraerlo (peek)
     * @return El elemento en la cima de la pila
     * @throws StackException si la pila está vacía
     */
    T peek() throws StackException;

    /**
     * Verifica si la pila está vacía
     * @return true si la pila está vacía, false en caso contrario
     */
    boolean isEmpty();

    /**
     * Obtiene el número de elementos en la pila
     * @return El tamaño actual de la pila
     */
    int size();

    /**
     * Elimina todos los elementos de la pila
     */
    void clear();
}
