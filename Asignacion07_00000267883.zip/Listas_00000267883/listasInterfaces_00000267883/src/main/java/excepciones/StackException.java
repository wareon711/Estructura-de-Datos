package excepciones;

/**
 * Archivo: StackException.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Excepcion personalizada para operaciones invalidas en pilas
 *
 * Esta clase representa una excepcion que se lanza cuando ocurre un error
 * en las operaciones de una pila, como intentar extraer de una pila vacia
 * o agregar a una pila llena.
 */
public class StackException extends Exception {

    /**
     * Constructor que crea una nueva instancia de StackException con un mensaje específico
     * @param message El mensaje de error que describe la excepción
     */
    public StackException(String message) {
        super(message);
    }

    /**
     * Constructor que crea una nueva instancia de StackException con un mensaje y causa
     * @param message El mensaje de error que describe la excepción
     * @param cause La causa original de la excepción
     */
    public StackException(String message, Throwable cause) {
        super(message, cause);
    }
}
