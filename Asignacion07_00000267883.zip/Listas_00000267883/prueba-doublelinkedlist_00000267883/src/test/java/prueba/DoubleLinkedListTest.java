package prueba;

import implementaciones.DoubleLinkedList;
import excepciones.ListException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Archivo: DoubleLinkedListTest.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Córdova
 * Propósito: Clase de pruebas unitarias para la clase DoubleLinkedList
 *
 * Esta clase contiene todas las pruebas unitarias necesarias para verificar
 * el correcto funcionamiento de la implementación DoubleLinkedList tanto para
 * tipos Integer como String.
 */
public class DoubleLinkedListTest {

    private DoubleLinkedList<Integer> integerList;
    private DoubleLinkedList<String> stringList;

    /**
     * Configuración inicial antes de cada prueba
     * Se ejecuta antes de cada método de prueba
     */
    @BeforeEach
    public void setUp() {
        // Crear instancias de DoubleLinkedList de tamaño 5
        integerList = new DoubleLinkedList<>(5);
        stringList = new DoubleLinkedList<>(5);
    }

    /**
     * Prueba la creación de una instancia DoubleLinkedList de tipo Integer vacía
     */
    @Test
    public void testCreateEmptyIntegerDoubleLinkedList() {
        assertTrue(integerList.isEmpty(), "La lista Integer debería estar vacía");
        assertEquals(0, integerList.size(), "El tamaño de la lista Integer debería ser 0");
        assertEquals(5, integerList.getCapacity(), "La capacidad debería ser 5");
    }

    /**
     * Prueba la creación de una instancia DoubleLinkedList de tipo String vacía
     */
    @Test
    public void testCreateEmptyStringDoubleLinkedList() {
        assertTrue(stringList.isEmpty(), "La lista String debería estar vacía");
        assertEquals(0, stringList.size(), "El tamaño de la lista String debería ser 0");
        assertEquals(5, stringList.getCapacity(), "La capacidad debería ser 5");
    }

    /**
     * Prueba agregar un entero a la lista
     */
    @Test
    public void testAddInteger() throws ListException {
        Integer testValue = 42;

        integerList.add(testValue);

        assertFalse(integerList.isEmpty(), "La lista no debería estar vacía");
        assertEquals(1, integerList.size(), "El tamaño debería ser 1");
        assertEquals(testValue, integerList.get(0), "El elemento agregado debería ser recuperable");
    }

    /**
     * Prueba agregar una cadena a la lista
     */
    @Test
    public void testAddString() throws ListException {
        String testValue = "Hola Mundo";

        stringList.add(testValue);

        assertFalse(stringList.isEmpty(), "La lista no debería estar vacía");
        assertEquals(1, stringList.size(), "El tamaño debería ser 1");
        assertEquals(testValue, stringList.get(0), "El elemento agregado debería ser recuperable");
    }

    /**
     * Prueba obtener el índice de la primera ocurrencia de un entero
     */
    @Test
    public void testIndexOfInteger() throws ListException {
        Integer testValue1 = 10;
        Integer testValue2 = 20;
        Integer testValue3 = 30;
        Integer nonExistentValue = 99;

        // Agregar varios elementos
        integerList.add(testValue1);
        integerList.add(testValue2);
        integerList.add(testValue3);
        integerList.add(testValue1); // Elemento duplicado

        // Probar indexOf
        assertEquals(0, integerList.indexOf(testValue1), "El índice de la primera ocurrencia de 10 debería ser 0");
        assertEquals(1, integerList.indexOf(testValue2), "El índice de 20 debería ser 1");
        assertEquals(2, integerList.indexOf(testValue3), "El índice de 30 debería ser 2");
        assertEquals(-1, integerList.indexOf(nonExistentValue), "El índice de un elemento no existente debería ser -1");
    }

    /**
     * Prueba obtener el índice de la última ocurrencia de un entero
     */
    @Test
    public void testLastIndexOfInteger() throws ListException {
        Integer testValue1 = 10;
        Integer testValue2 = 20;

        // Agregar elementos con duplicados
        integerList.add(testValue1); // índice 0
        integerList.add(testValue2); // índice 1
        integerList.add(testValue1); // índice 2
        integerList.add(testValue2); // índice 3
        integerList.add(testValue1); // índice 4

        // Probar lastIndexOf
        assertEquals(4, integerList.lastIndexOf(testValue1), "La última ocurrencia de 10 debería estar en índice 4");
        assertEquals(3, integerList.lastIndexOf(testValue2), "La última ocurrencia de 20 debería estar en índice 3");
        assertEquals(-1, integerList.lastIndexOf(99), "El elemento no existente debería retornar -1");
    }

    /**
     * Prueba obtener el índice de la primera ocurrencia de una cadena
     */
    @Test
    public void testIndexOfString() throws ListException {
        String testValue1 = "Java";
        String testValue2 = "Python";
        String testValue3 = "C++";
        String nonExistentValue = "JavaScript";

        // Agregar varios elementos
        stringList.add(testValue1);
        stringList.add(testValue2);
        stringList.add(testValue3);
        stringList.add(testValue1); // Elemento duplicado

        // Probar indexOf
        assertEquals(0, stringList.indexOf(testValue1), "El índice de la primera ocurrencia de 'Java' debería ser 0");
        assertEquals(1, stringList.indexOf(testValue2), "El índice de 'Python' debería ser 1");
        assertEquals(2, stringList.indexOf(testValue3), "El índice de 'C++' debería ser 2");
        assertEquals(-1, stringList.indexOf(nonExistentValue), "El índice de un elemento no existente debería ser -1");
    }

    /**
     * Prueba obtener el índice de la última ocurrencia de una cadena
     */
    @Test
    public void testLastIndexOfString() throws ListException {
        String testValue1 = "Java";
        String testValue2 = "Python";

        // Agregar elementos con duplicados
        stringList.add(testValue1);  // índice 0
        stringList.add(testValue2);  // índice 1
        stringList.add(testValue1);  // índice 2
        stringList.add(testValue2);  // índice 3
        stringList.add(testValue1);  // índice 4

        // Probar lastIndexOf
        assertEquals(4, stringList.lastIndexOf(testValue1), "La última ocurrencia de 'Java' debería estar en índice 4");
        assertEquals(3, stringList.lastIndexOf(testValue2), "La última ocurrencia de 'Python' debería estar en índice 3");
        assertEquals(-1, stringList.lastIndexOf("Ruby"), "El elemento no existente debería retornar -1");
    }

    /**
     * Prueba eliminar la primera ocurrencia de un entero
     */
    @Test
    public void testRemoveInteger() throws ListException {
        Integer testValue1 = 100;
        Integer testValue2 = 200;
        Integer nonExistentValue = 999;

        // Agregar elementos
        integerList.add(testValue1);
        integerList.add(testValue2);
        integerList.add(testValue1); // Duplicado
        integerList.add(testValue2); // Duplicado

        int initialSize = integerList.size();

        // Remover primera ocurrencia
        assertTrue(integerList.remove(testValue1), "Debería poder remover el elemento existente");
        assertEquals(initialSize - 1, integerList.size(), "El tamaño debería decrementar");
        assertEquals(0, integerList.indexOf(testValue2), "El elemento 200 ahora debería estar en índice 0");

        // Verificar que el duplicado sigue en la lista
        assertEquals(1, integerList.indexOf(testValue1), "El elemento duplicado debería seguir en la lista");

        // Intentar remover elemento no existente
        assertFalse(integerList.remove(nonExistentValue), "No debería poder remover un elemento no existente");
    }

    /**
     * Prueba eliminar la última ocurrencia de un entero
     */
    @Test
    public void testRemoveLastInteger() throws ListException {
        Integer testValue = 100;

        // Agregar elementos con duplicados
        integerList.add(testValue); // índice 0
        integerList.add(200);       // índice 1
        integerList.add(testValue); // índice 2
        integerList.add(300);       // índice 3
        integerList.add(testValue); // índice 4

        int initialSize = integerList.size();

        // Remover última ocurrencia
        assertTrue(integerList.removeLast(testValue), "Debería poder remover la última ocurrencia");
        assertEquals(initialSize - 1, integerList.size(), "El tamaño debería decrementar");

        // Verificar que se removió la última ocurrencia (índice 4)
        assertEquals(2, integerList.lastIndexOf(testValue), "La nueva última ocurrencia debería estar en índice 2");

        // Intentar remover última ocurrencia de elemento no existente
        assertFalse(integerList.removeLast(999), "No debería poder remover un elemento no existente");
    }

    /**
     * Prueba eliminar la primera ocurrencia de una cadena
     */
    @Test
    public void testRemoveString() throws ListException {
        String testValue1 = "Primero";
        String testValue2 = "Segundo";
        String nonExistentValue = "NoExiste";

        // Agregar elementos
        stringList.add(testValue1);
        stringList.add(testValue2);
        stringList.add(testValue1); // Duplicado
        stringList.add(testValue2); // Duplicado

        int initialSize = stringList.size();

        // Remover primera ocurrencia
        assertTrue(stringList.remove(testValue1), "Debería poder remover el elemento existente");
        assertEquals(initialSize - 1, stringList.size(), "El tamaño debería decrementar");
        assertEquals(0, stringList.indexOf(testValue2), "El elemento 'Segundo' ahora debería estar en índice 0");

        // Verificar que el duplicado sigue en la lista
        assertEquals(1, stringList.indexOf(testValue1), "El elemento duplicado debería seguir en la lista");

        // Intentar remover elemento no existente
        assertFalse(stringList.remove(nonExistentValue), "No debería poder remover un elemento no existente");
    }

    /**
     * Prueba eliminar la última ocurrencia de una cadena
     */
    @Test
    public void testRemoveLastString() throws ListException {
        String testValue = "Java";

        // Agregar elementos con duplicados
        stringList.add(testValue);  // índice 0
        stringList.add("Python");   // índice 1
        stringList.add(testValue);  // índice 2
        stringList.add("C++");      // índice 3
        stringList.add(testValue);  // índice 4

        int initialSize = stringList.size();

        // Remover última ocurrencia
        assertTrue(stringList.removeLast(testValue), "Debería poder remover la última ocurrencia");
        assertEquals(initialSize - 1, stringList.size(), "El tamaño debería decrementar");

        // Verificar que se removió la última ocurrencia (índice 4)
        assertEquals(2, stringList.lastIndexOf(testValue), "La nueva última ocurrencia debería estar en índice 2");

        // Intentar remover última ocurrencia de elemento no existente
        assertFalse(stringList.removeLast("Ruby"), "No debería poder remover un elemento no existente");
    }

    /**
     * Prueba el método set() para reemplazar elementos
     */
    @Test
    public void testSetMethod() throws ListException {
        Integer oldValue = 50;
        Integer newValue = 75;

        // Agregar un elemento
        integerList.add(oldValue);

        // Reemplazar el elemento
        integerList.set(newValue, 0);

        assertEquals(newValue, integerList.get(0), "El elemento debería haber sido reemplazado");
        assertEquals(1, integerList.size(), "El tamaño no debería cambiar");
    }

    /**
     * Prueba el método clear() para limpiar la lista
     */
    @Test
    public void testClearMethod() throws ListException {
        // Agregar varios elementos
        integerList.add(1);
        integerList.add(2);
        integerList.add(3);

        assertFalse(integerList.isEmpty(), "La lista debería tener elementos");

        // Limpiar la lista
        integerList.clear();

        assertTrue(integerList.isEmpty(), "La lista debería estar vacía después de clear()");
        assertEquals(0, integerList.size(), "El tamaño debería ser 0 después de clear()");
    }

    /**
     * Prueba la navegación bidireccional
     */
    @Test
    public void testBidirectionalNavigation() throws ListException {
        // Agregar elementos
        integerList.add(10);
        integerList.add(20);
        integerList.add(30);

        // Verificar orden normal
        assertEquals("[10, 20, 30]", integerList.toString());

        // Verificar orden inverso
        assertEquals("[30, 20, 10]", integerList.toStringReverse());
    }

    /**
     * Prueba la inserción en diferentes posiciones
     */
    @Test
    public void testAddAtPosition() throws ListException {
        // Agregar en posición 0 (lista vacía)
        integerList.add(20, 0);
        assertEquals(20, integerList.get(0));

        // Agregar al inicio
        integerList.add(10, 0);
        assertEquals(10, integerList.get(0));
        assertEquals(20, integerList.get(1));

        // Agregar al final
        integerList.add(40, 2);
        assertEquals(40, integerList.get(2));

        // Agregar en el medio
        integerList.add(30, 2);
        assertEquals("[10, 20, 30, 40]", integerList.toString());
    }

    /**
     * Prueba la remoción por índice en diferentes posiciones
     */
    @Test
    public void testRemoveByIndex() throws ListException {
        // Agregar elementos
        integerList.add(10);
        integerList.add(20);
        integerList.add(30);
        integerList.add(40);

        // Remover del medio
        Integer removed = integerList.remove(1);
        assertEquals(20, removed);
        assertEquals("[10, 30, 40]", integerList.toString());

        // Remover del inicio
        removed = integerList.remove(0);
        assertEquals(10, removed);
        assertEquals("[30, 40]", integerList.toString());

        // Remover del final
        removed = integerList.remove(1);
        assertEquals(40, removed);
        assertEquals("[30]", integerList.toString());
    }

    /**
     * Prueba excepciones en lista vacía
     */
    @Test
    public void testEmptyListExceptions() {
        // Probar get() en lista vacía
        assertThrows(ListException.class, () -> {
            integerList.get(0);
        }, "get() debería lanzar excepción en lista vacía");

        // Probar remove(index) en lista vacía
        assertThrows(ListException.class, () -> {
            integerList.remove(0);
        }, "remove(index) debería lanzar excepción en lista vacía");

        // Probar set() en lista vacía
        assertThrows(ListException.class, () -> {
            integerList.set(10, 0);
        }, "set() debería lanzar excepción en lista vacía");

        // Probar remove(object) en lista vacía
        assertThrows(ListException.class, () -> {
            integerList.remove(Integer.valueOf(10));
        }, "remove(object) debería lanzar excepción en lista vacía");

        // Probar removeLast(object) en lista vacía
        assertThrows(ListException.class, () -> {
            integerList.removeLast(Integer.valueOf(10));
        }, "removeLast(object) debería lanzar excepción en lista vacía");
    }

    /**
     * Prueba excepciones por índices fuera de rango
     */
    @Test
    public void testIndexOutOfBoundsExceptions() throws ListException {
        // Agregar un elemento
        integerList.add(10);

        // Probar índices negativos
        assertThrows(ListException.class, () -> {
            integerList.get(-1);
        }, "get() debería lanzar excepción con índice negativo");

        // Probar índices fuera del límite superior
        assertThrows(ListException.class, () -> {
            integerList.get(1);
        }, "get() debería lanzar excepción con índice fuera de límite");

        // Probar set() con índice inválido
        assertThrows(ListException.class, () -> {
            integerList.set(20, 5);
        }, "set() debería lanzar excepción con índice fuera de límite");
    }

    /**
     * Prueba el comportamiento cuando la lista está llena
     */
    @Test
    public void testFullListException() throws ListException {
        // Llenar la lista hasta su capacidad (5 elementos)
        for (int i = 0; i < 5; i++) {
            integerList.add(i);
        }

        // Intentar agregar un elemento más debería lanzar excepción
        assertThrows(ListException.class, () -> {
            integerList.add(5);
        }, "add() debería lanzar excepción cuando la lista está llena");
    }

    /**
     * Prueba funcional completa que demuestra el uso de DoubleLinkedList con Integer
     */
    @Test
    public void testCompleteIntegerWorkflow() throws ListException {
        // a) Crear instancia DoubleLinkedList de tamaño 5 de tipo Integer, vacía
        DoubleLinkedList<Integer> lista = new DoubleLinkedList<>(5);
        assertTrue(lista.isEmpty());

        // b) Agregar un entero a la lista
        lista.add(42);
        lista.add(42);
        lista.add(99);
        assertEquals(3, lista.size());

        // c) Obtener el índice de la primera ocurrencia de un entero
        int indice = lista.indexOf(42);
        assertEquals(0, indice);

        // d) Obtener el índice de la última ocurrencia de un entero
        int ultimoIndice = lista.lastIndexOf(42);
        assertEquals(1, ultimoIndice);

        // e) Eliminar la primera ocurrencia de un entero
        boolean eliminado = lista.remove(Integer.valueOf(42));
        assertTrue(eliminado);
        assertEquals(2, lista.size());

        // f) Eliminar la última ocurrencia de un entero
        lista.add(99); // Agregar otro 99
        boolean eliminadoUltimo = lista.removeLast(Integer.valueOf(99));
        assertTrue(eliminadoUltimo);
        assertEquals(2, lista.size());
    }

    /**
     * Prueba funcional completa que demuestra el uso de DoubleLinkedList con String
     */
    @Test
    public void testCompleteStringWorkflow() throws ListException {
        // g) Crear instancia DoubleLinkedList de tamaño 5 de tipo String, vacía
        DoubleLinkedList<String> lista = new DoubleLinkedList<>(5);
        assertTrue(lista.isEmpty());

        // h) Agregar una cadena a la lista
        lista.add("Hola");
        lista.add("Hola");
        lista.add("Mundo");
        assertEquals(3, lista.size());

        // i) Obtener el índice de la primera ocurrencia de una cadena
        int indice = lista.indexOf("Hola");
        assertEquals(0, indice);

        // j) Obtener el índice de la última ocurrencia de una cadena
        int ultimoIndice = lista.lastIndexOf("Hola");
        assertEquals(1, ultimoIndice);

        // k) Eliminar la primera ocurrencia de una cadena
        boolean eliminado = lista.remove("Hola");
        assertTrue(eliminado);
        assertEquals(2, lista.size());

        // l) Eliminar la última ocurrencia de una cadena
        lista.add("Mundo"); // Agregar otro "Mundo"
        boolean eliminadoUltimo = lista.removeLast("Mundo");
        assertTrue(eliminadoUltimo);
        assertEquals(2, lista.size());
    }

    /**
     * Prueba el manejo de valores nulos
     */
    @Test
    public void testNullValues() throws ListException {
        // Agregar valor nulo
        integerList.add(null);
        integerList.add(10);
        integerList.add(null);

        assertEquals(3, integerList.size());
        assertNull(integerList.get(0));

        // Buscar valor nulo
        assertEquals(0, integerList.indexOf(null));
        assertEquals(2, integerList.lastIndexOf(null));

        // Remover primera ocurrencia de null
        assertTrue(integerList.remove(null));
        assertEquals(2, integerList.size());
        assertEquals(1, integerList.lastIndexOf(null));

        // Remover última ocurrencia de null
        assertTrue(integerList.removeLast(null));
        assertEquals(1, integerList.size());
    }

    /**
     * Prueba de rendimiento y optimización de búsqueda bidireccional
     */
    @Test
    public void testPerformanceOptimization() throws ListException {
        DoubleLinkedList<Integer> bigList = new DoubleLinkedList<>(100);

        // Agregar muchos elementos
        for (int i = 0; i < 100; i++) {
            bigList.add(i);
        }

        assertEquals(100, bigList.size());

        // Verificar acceso optimizado desde el inicio
        assertEquals(Integer.valueOf(10), bigList.get(10));

        // Verificar acceso optimizado desde el final
        assertEquals(Integer.valueOf(90), bigList.get(90));

        // Limpiar la lista
        bigList.clear();
        assertTrue(bigList.isEmpty());
    }

    /**
     * Prueba la diferencia entre indexOf y lastIndexOf
     */
    @Test
    public void testIndexOfVsLastIndexOf() throws ListException {
        Integer testValue = 100;

        // Agregar elementos con el mismo valor en diferentes posiciones
        integerList.add(testValue);
        integerList.add(200);
        integerList.add(testValue);
        integerList.add(300);
        integerList.add(testValue);

        // indexOf encuentra la primera ocurrencia
        assertEquals(0, integerList.indexOf(testValue));

        // lastIndexOf encuentra la última ocurrencia
        assertEquals(4, integerList.lastIndexOf(testValue));

        // Son diferentes
        assertNotEquals(integerList.indexOf(testValue), integerList.lastIndexOf(testValue));
    }
}
