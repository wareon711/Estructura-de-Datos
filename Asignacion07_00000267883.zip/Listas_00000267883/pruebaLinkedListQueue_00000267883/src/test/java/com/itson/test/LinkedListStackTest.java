package com.itson.test;

import implementaciones.LinkedListStack;
import excepciones.StackException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Archivo: LinkedListStackTest.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Clase de pruebas unitarias para LinkedListStack
 *
 * Esta clase contiene todas las pruebas unitarias para verificar el
 * correcto funcionamiento de LinkedListStack con tipos Integer y String.
 */
public class LinkedListStackTest {

    private LinkedListStack<Integer> integerStack;
    private LinkedListStack<String> stringStack;

    @BeforeEach
    public void setUp() {
        integerStack = new LinkedListStack<>(5);
        stringStack = new LinkedListStack<>(5);
    }

    @Test
    public void testCreateEmptyIntegerStack() {
        assertTrue(integerStack.isEmpty());
        assertEquals(0, integerStack.size());
    }

    @Test
    public void testCreateEmptyStringStack() {
        assertTrue(stringStack.isEmpty());
        assertEquals(0, stringStack.size());
    }

    @Test
    public void testPushInteger() throws StackException {
        integerStack.push(42);

        assertFalse(integerStack.isEmpty());
        assertEquals(1, integerStack.size());
        assertEquals(42, integerStack.peek());
    }

    @Test
    public void testPushString() throws StackException {
        stringStack.push("Hola");

        assertFalse(stringStack.isEmpty());
        assertEquals(1, stringStack.size());
        assertEquals("Hola", stringStack.peek());
    }

    @Test
    public void testPopInteger() throws StackException {
        integerStack.push(10);
        integerStack.push(20);
        integerStack.push(30);

        Integer top = integerStack.pop();
        assertEquals(30, top);
        assertEquals(2, integerStack.size());
        assertEquals(20, integerStack.peek());
    }

    @Test
    public void testPopString() throws StackException {
        stringStack.push("Primero");
        stringStack.push("Segundo");
        stringStack.push("Tercero");

        String top = stringStack.pop();
        assertEquals("Tercero", top);
        assertEquals(2, stringStack.size());
        assertEquals("Segundo", stringStack.peek());
    }

    @Test
    public void testEmptyStackExceptionInteger() {
        assertThrows(StackException.class, () -> {
            integerStack.pop();
        });

        assertThrows(StackException.class, () -> {
            integerStack.peek();
        });
    }

    @Test
    public void testEmptyStackExceptionString() {
        assertThrows(StackException.class, () -> {
            stringStack.pop();
        });

        assertThrows(StackException.class, () -> {
            stringStack.peek();
        });
    }

    @Test
    public void testFullStackExceptionInteger() throws StackException {
        for (int i = 0; i < 5; i++) {
            integerStack.push(i);
        }

        assertThrows(StackException.class, () -> {
            integerStack.push(5);
        });
    }

    @Test
    public void testFullStackExceptionString() throws StackException {
        for (int i = 0; i < 5; i++) {
            stringStack.push("Elemento" + i);
        }

        assertThrows(StackException.class, () -> {
            stringStack.push("Extra");
        });
    }

    @Test
    public void testLIFOBehavior() throws StackException {
        integerStack.push(1);
        integerStack.push(2);
        integerStack.push(3);

        assertEquals(3, integerStack.pop());
        assertEquals(2, integerStack.pop());
        assertEquals(1, integerStack.pop());
        assertTrue(integerStack.isEmpty());
    }

    @Test
    public void testPeekDoesNotModify() throws StackException {
        integerStack.push(42);

        assertEquals(42, integerStack.peek());
        assertEquals(1, integerStack.size());
        assertEquals(42, integerStack.peek());
    }

    @Test
    public void testClear() throws StackException {
        integerStack.push(1);
        integerStack.push(2);
        integerStack.push(3);

        assertFalse(integerStack.isEmpty());
        integerStack.clear();
        assertTrue(integerStack.isEmpty());
        assertEquals(0, integerStack.size());
    }

    @Test
    public void testLinkedListEfficiency() throws StackException {
        // Las operaciones push y pop son O(1) en LinkedList
        for (int round = 0; round < 3; round++) {
            for (int i = 0; i < 5; i++) {
                integerStack.push(i);
            }

            for (int i = 4; i >= 0; i--) {
                assertEquals(i, integerStack.pop());
            }

            assertTrue(integerStack.isEmpty());
        }
    }
}
