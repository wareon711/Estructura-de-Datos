package implementaciones;

import interfaces.IStack;
import excepciones.StackException;
import excepciones.ListException;

/**
 * Archivo: LinkedListStack.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Implementacion de una pila (Stack) basada en LinkedList
 *
 * Esta clase implementa una pila con comportamiento LIFO (Last In, First Out)
 * utilizando LinkedList como estructura de datos subyacente. Los elementos se
 * agregan y extraen desde el inicio de la lista para mayor eficiencia.
 */
public class LinkedListStack<T> extends LinkedList<T> implements IStack<T> {

    /**
     * Constructor que crea una pila vacía con la capacidad especificada
     * @param capacity La capacidad máxima de la pila
     */
    public LinkedListStack(int capacity) {
        super(capacity);
    }

    /**
     * Constructor que crea una pila vacía sin límite de capacidad
     */
    public LinkedListStack() {
        super();
    }

    /**
     * Agrega un elemento en la cima de la pila
     * @param element El elemento a agregar
     * @throws StackException si la pila está llena
     */
    @Override
    public void push(T element) throws StackException {
        try {
            // Agregar al inicio de la lista (cima de la pila) - O(1)
            add(element, 0);
        } catch (ListException e) {
            throw new StackException("La pila esta llena", e);
        }
    }

    /**
     * Extrae y retorna el elemento en la cima de la pila
     * @return El elemento que estaba en la cima
     * @throws StackException si la pila está vacía
     */
    @Override
    public T pop() throws StackException {
        if (isEmpty()) {
            throw new StackException("La pila esta vacia");
        }

        try {
            // Remover el primer elemento (cima de la pila) - O(1)
            return remove(0);
        } catch (ListException e) {
            throw new StackException("Error al extraer elemento de la pila", e);
        }
    }

    /**
     * Retorna el elemento en la cima de la pila sin extraerlo
     * @return El elemento en la cima
     * @throws StackException si la pila está vacía
     */
    @Override
    public T peek() throws StackException {
        if (isEmpty()) {
            throw new StackException("La pila esta vacia");
        }

        try {
            // Obtener el primer elemento sin removerlo - O(1)
            return get(0);
        } catch (ListException e) {
            throw new StackException("Error al consultar la cima de la pila", e);
        }
    }

    /**
     * Representación en cadena de la pila
     * Muestra los elementos desde la cima hasta la base
     * @return Una representación en cadena de la pila
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "Pila[]";
        }
        return "Pila[cima → " + super.toString().substring(1);
    }
}
