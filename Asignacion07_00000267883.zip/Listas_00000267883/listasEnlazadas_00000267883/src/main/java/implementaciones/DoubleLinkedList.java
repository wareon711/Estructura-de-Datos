package implementaciones;

import interfaces.IDoubleList;
import excepciones.ListException;

/**
 * Archivo: DoubleLinkedList.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Córdova
 * Propósito: Implementación de una lista genérica utilizando una lista doblemente enlazada
 *
 * Esta clase implementa la interfaz IDoubleList utilizando una estructura de lista
 * doblemente enlazada para almacenar los elementos. Cada nodo contiene referencias
 * tanto al nodo siguiente como al anterior, permitiendo navegación bidireccional.
 */
public class DoubleLinkedList<T> implements IDoubleList<T> {

    // Referencia al primer nodo de la lista
    private DoubleNode<T> head;

    // Referencia al último nodo de la lista
    private DoubleNode<T> tail;

    // Número actual de elementos en la lista
    private int size;

    // Capacidad máxima de la lista
    private int capacity;

    /**
     * Constructor que crea una nueva DoubleLinkedList con la capacidad especificada
     * @param capacity La capacidad máxima de la lista
     */
    public DoubleLinkedList(int capacity) {
        this.capacity = capacity;
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    /**
     * Constructor que crea una DoubleLinkedList sin límite de capacidad
     */
    public DoubleLinkedList() {
        this.capacity = Integer.MAX_VALUE;
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    /**
     * Agrega un elemento al final de la lista
     * @param o El elemento a agregar
     * @throws ListException si la lista está llena
     */
    @Override
    public void add(T o) throws ListException {
        // Verificar si la lista está llena
        if (size >= capacity) {
            throw new ListException("La lista está llena");
        }

        // Crear nuevo nodo
        DoubleNode<T> newNode = new DoubleNode<>(o);

        // Si la lista está vacía
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            // Agregar al final
            tail.setNext(newNode);
            newNode.setPrevious(tail);
            tail = newNode;
        }

        size++;
    }

    /**
     * Agrega un elemento en la posición especificada
     * @param o El elemento a agregar
     * @param i La posición donde insertar el elemento
     * @throws ListException si el índice está fuera de rango o la lista está llena
     */
    @Override
    public void add(T o, int i) throws ListException {
        // Verificar si la lista está llena
        if (size >= capacity) {
            throw new ListException("La lista está llena");
        }

        // Verificar que el índice sea válido
        if (i < 0 || i > size) {
            throw new ListException("Índice fuera de rango: " + i);
        }

        // Crear nuevo nodo
        DoubleNode<T> newNode = new DoubleNode<>(o);

        // Caso especial: insertar en la primera posición
        if (i == 0) {
            if (head == null) {
                head = newNode;
                tail = newNode;
            } else {
                newNode.setNext(head);
                head.setPrevious(newNode);
                head = newNode;
            }
        }
        // Caso especial: insertar al final
        else if (i == size) {
            tail.setNext(newNode);
            newNode.setPrevious(tail);
            tail = newNode;
        }
        // Caso general: insertar en el medio
        else {
            DoubleNode<T> current = getNodeAt(i);
            DoubleNode<T> prevNode = current.getPrevious();

            newNode.setNext(current);
            newNode.setPrevious(prevNode);
            prevNode.setNext(newNode);
            current.setPrevious(newNode);
        }

        size++;
    }

    /**
     * Obtiene el elemento en la posición especificada
     * @param i La posición del elemento
     * @return El elemento en la posición i
     * @throws ListException si el índice está fuera de rango o la lista está vacía
     */
    @Override
    public T get(int i) throws ListException {
        // Verificar si la lista está vacía
        if (isEmpty()) {
            throw new ListException("La lista está vacía");
        }

        // Verificar que el índice sea válido
        if (i < 0 || i >= size) {
            throw new ListException("Índice fuera de rango: " + i);
        }

        return getNodeAt(i).getData();
    }

    /**
     * Remueve el elemento en la posición especificada
     * @param i La posición del elemento a remover
     * @return El elemento removido
     * @throws ListException si el índice está fuera de rango o la lista está vacía
     */
    @Override
    public T remove(int i) throws ListException {
        // Verificar si la lista está vacía
        if (isEmpty()) {
            throw new ListException("La lista está vacía");
        }

        // Verificar que el índice sea válido
        if (i < 0 || i >= size) {
            throw new ListException("Índice fuera de rango: " + i);
        }

        DoubleNode<T> nodeToRemove = getNodeAt(i);
        T removedData = nodeToRemove.getData();

        // Caso especial: solo hay un nodo
        if (size == 1) {
            head = null;
            tail = null;
        }
        // Caso especial: remover el primer nodo
        else if (i == 0) {
            head = head.getNext();
            head.setPrevious(null);
        }
        // Caso especial: remover el último nodo
        else if (i == size - 1) {
            tail = tail.getPrevious();
            tail.setNext(null);
        }
        // Caso general: remover nodo en el medio
        else {
            DoubleNode<T> prevNode = nodeToRemove.getPrevious();
            DoubleNode<T> nextNode = nodeToRemove.getNext();

            prevNode.setNext(nextNode);
            nextNode.setPrevious(prevNode);
        }

        size--;
        return removedData;
    }

    /**
     * Verifica si la lista está vacía
     * @return true si la lista está vacía, false en caso contrario
     */
    @Override
    public boolean isEmpty() {
        return head == null || size == 0;
    }

    /**
     * Obtiene el número de elementos en la lista
     * @return El tamaño actual de la lista
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Reemplaza el elemento en la posición especificada
     * @param o El nuevo elemento
     * @param i La posición del elemento a reemplazar
     * @throws ListException si la lista está vacía o el índice está fuera de rango
     */
    @Override
    public void set(T o, int i) throws ListException {
        // Verificar si la lista está vacía
        if (isEmpty()) {
            throw new ListException("La lista está vacía");
        }

        // Verificar que el índice sea válido
        if (i < 0 || i >= size) {
            throw new ListException("Índice fuera de rango: " + i);
        }

        // Obtener el nodo y reemplazar su dato
        getNodeAt(i).setData(o);
    }

    /**
     * Elimina la primera ocurrencia del elemento especificado
     * @param o El elemento a eliminar
     * @return true si el elemento fue encontrado y eliminado, false en caso contrario
     * @throws ListException si la lista está vacía
     */
    @Override
    public boolean remove(T o) throws ListException {
        // Verificar si la lista está vacía
        if (isEmpty()) {
            throw new ListException("La lista está vacía");
        }

        DoubleNode<T> current = head;
        int index = 0;

        // Buscar el elemento desde el inicio
        while (current != null) {
            boolean dataEquals = (current.getData() == null && o == null) ||
                                (current.getData() != null && current.getData().equals(o));

            if (dataEquals) {
                remove(index);
                return true;
            }

            current = current.getNext();
            index++;
        }

        return false;
    }

    /**
     * Obtiene el índice de la primera ocurrencia del elemento especificado
     * @param o El elemento a buscar
     * @return El índice del elemento o -1 si no se encuentra
     */
    @Override
    public int indexOf(T o) {
        DoubleNode<T> current = head;
        int index = 0;

        // Buscar desde el inicio
        while (current != null) {
            boolean dataEquals = (current.getData() == null && o == null) ||
                                (current.getData() != null && current.getData().equals(o));

            if (dataEquals) {
                return index;
            }

            current = current.getNext();
            index++;
        }

        return -1;
    }

    /**
     * Obtiene el índice de la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a buscar
     * @return El índice de la última ocurrencia del elemento o -1 si no se encuentra
     */
    @Override
    public int lastIndexOf(T o) {
        DoubleNode<T> current = tail;
        int index = size - 1;

        // Buscar desde el final hacia el inicio
        while (current != null) {
            boolean dataEquals = (current.getData() == null && o == null) ||
                                (current.getData() != null && current.getData().equals(o));

            if (dataEquals) {
                return index;
            }

            current = current.getPrevious();
            index--;
        }

        return -1;
    }

    /**
     * Elimina la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a eliminar
     * @return true si el elemento fue encontrado y eliminado, false en caso contrario
     * @throws ListException si la lista está vacía
     */
    @Override
    public boolean removeLast(T o) throws ListException {
        // Verificar si la lista está vacía
        if (isEmpty()) {
            throw new ListException("La lista está vacía");
        }

        DoubleNode<T> current = tail;
        int index = size - 1;

        // Buscar desde el final hacia el inicio
        while (current != null) {
            boolean dataEquals = (current.getData() == null && o == null) ||
                                (current.getData() != null && current.getData().equals(o));

            if (dataEquals) {
                remove(index);
                return true;
            }

            current = current.getPrevious();
            index--;
        }

        return false;
    }

    /**
     * Elimina todos los elementos de la lista
     */
    @Override
    public void clear() {
        // Eliminar todas las referencias
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Método auxiliar que obtiene el nodo en la posición especificada
     * Optimiza la búsqueda decidiendo si recorrer desde el inicio o desde el final
     * @param index El índice del nodo a obtener
     * @return El nodo en la posición especificada
     */
    private DoubleNode<T> getNodeAt(int index) {
        DoubleNode<T> current;

        // Optimización: decidir desde dónde empezar la búsqueda
        if (index < size / 2) {
            // Buscar desde el inicio
            current = head;
            for (int i = 0; i < index; i++) {
                current = current.getNext();
            }
        } else {
            // Buscar desde el final
            current = tail;
            for (int i = size - 1; i > index; i--) {
                current = current.getPrevious();
            }
        }

        return current;
    }

    /**
     * Representación en cadena de la lista
     * @return Una representación en cadena de los elementos de la lista
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("[");

        DoubleNode<T> current = head;
        while (current != null) {
            sb.append(current.getData());
            if (current.getNext() != null) {
                sb.append(", ");
            }
            current = current.getNext();
        }

        sb.append("]");
        return sb.toString();
    }

    /**
     * Representación en cadena de la lista en orden inverso
     * @return Una representación en cadena de los elementos desde el final
     */
    public String toStringReverse() {
        if (isEmpty()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("[");

        DoubleNode<T> current = tail;
        while (current != null) {
            sb.append(current.getData());
            if (current.getPrevious() != null) {
                sb.append(", ");
            }
            current = current.getPrevious();
        }

        sb.append("]");
        return sb.toString();
    }

    /**
     * Obtiene la capacidad máxima de la lista
     * @return La capacidad máxima
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Establece la capacidad máxima de la lista
     * @param capacity La nueva capacidad máxima
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}
