package implementaciones;

/**
 * Archivo: DoubleNode.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Córdova
 * Propósito: Clase que representa un nodo en una lista doblemente enlazada
 *
 * Esta clase encapsula los datos y las referencias al siguiente y anterior nodo
 * en una estructura de lista doblemente enlazada. Es una clase de apoyo para
 * la implementación de DoubleLinkedList.
 */
public class DoubleNode<T> {

    // Dato almacenado en el nodo
    private T data;

    // Referencia al siguiente nodo en la lista
    private DoubleNode<T> next;

    // Referencia al nodo anterior en la lista
    private DoubleNode<T> previous;

    /**
     * Constructor que crea un nuevo nodo con el dato especificado
     * @param data El dato a almacenar en el nodo
     */
    public DoubleNode(T data) {
        this.data = data;
        this.next = null;
        this.previous = null;
    }

    /**
     * Constructor que crea un nuevo nodo con dato y referencias
     * @param data El dato a almacenar en el nodo
     * @param next La referencia al siguiente nodo
     * @param previous La referencia al nodo anterior
     */
    public DoubleNode(T data, DoubleNode<T> next, DoubleNode<T> previous) {
        this.data = data;
        this.next = next;
        this.previous = previous;
    }

    /**
     * Obtiene el dato almacenado en el nodo
     * @return El dato del nodo
     */
    public T getData() {
        return data;
    }

    /**
     * Establece el dato del nodo
     * @param data El nuevo dato a almacenar
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     * Obtiene la referencia al siguiente nodo
     * @return El siguiente nodo en la lista
     */
    public DoubleNode<T> getNext() {
        return next;
    }

    /**
     * Establece la referencia al siguiente nodo
     * @param next El nuevo siguiente nodo
     */
    public void setNext(DoubleNode<T> next) {
        this.next = next;
    }

    /**
     * Obtiene la referencia al nodo anterior
     * @return El nodo anterior en la lista
     */
    public DoubleNode<T> getPrevious() {
        return previous;
    }

    /**
     * Establece la referencia al nodo anterior
     * @param previous El nuevo nodo anterior
     */
    public void setPrevious(DoubleNode<T> previous) {
        this.previous = previous;
    }

    /**
     * Representación en cadena del nodo
     * @return Una representación en cadena del dato del nodo
     */
    @Override
    public String toString() {
        return data != null ? data.toString() : "null";
    }
}
