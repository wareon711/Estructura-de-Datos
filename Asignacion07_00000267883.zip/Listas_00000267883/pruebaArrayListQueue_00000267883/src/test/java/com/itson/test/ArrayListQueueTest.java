package com.itson.test;

import implementaciones.ArrayListQueue;
import excepciones.QueueException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Archivo: ArrayListQueueTest.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Clase de pruebas unitarias para ArrayListQueue
 *
 * Esta clase contiene todas las pruebas unitarias para verificar el
 * correcto funcionamiento de ArrayListQueue con tipos Integer y String.
 */
public class ArrayListQueueTest {

    private ArrayListQueue<Integer> integerQueue;
    private ArrayListQueue<String> stringQueue;

    @BeforeEach
    public void setUp() {
        integerQueue = new ArrayListQueue<>(5);
        stringQueue = new ArrayListQueue<>(5);
    }

    /**
     * Prueba creación de cola Integer vacía
     */
    @Test
    public void testCreateEmptyIntegerQueue() {
        assertTrue(integerQueue.isEmpty());
        assertEquals(0, integerQueue.size());
    }

    /**
     * Prueba creación de cola String vacía
     */
    @Test
    public void testCreateEmptyStringQueue() {
        assertTrue(stringQueue.isEmpty());
        assertEquals(0, stringQueue.size());
    }

    /**
     * Prueba agregar entero a la cola
     */
    @Test
    public void testEnqueueInteger() throws QueueException {
        integerQueue.enqueue(42);

        assertFalse(integerQueue.isEmpty());
        assertEquals(1, integerQueue.size());
        assertEquals(42, integerQueue.peek());
    }

    /**
     * Prueba agregar cadena a la cola
     */
    @Test
    public void testEnqueueString() throws QueueException {
        stringQueue.enqueue("Hola");

        assertFalse(stringQueue.isEmpty());
        assertEquals(1, stringQueue.size());
        assertEquals("Hola", stringQueue.peek());
    }

    /**
     * Prueba extraer entero de la cola
     */
    @Test
    public void testDequeueInteger() throws QueueException {
        integerQueue.enqueue(10);
        integerQueue.enqueue(20);
        integerQueue.enqueue(30);

        Integer first = integerQueue.dequeue();
        assertEquals(10, first);
        assertEquals(2, integerQueue.size());
        assertEquals(20, integerQueue.peek());
    }

    /**
     * Prueba extraer cadena de la cola
     */
    @Test
    public void testDequeueString() throws QueueException {
        stringQueue.enqueue("Primero");
        stringQueue.enqueue("Segundo");
        stringQueue.enqueue("Tercero");

        String first = stringQueue.dequeue();
        assertEquals("Primero", first);
        assertEquals(2, stringQueue.size());
        assertEquals("Segundo", stringQueue.peek());
    }

    /**
     * Prueba excepción por cola vacía (Integer)
     */
    @Test
    public void testEmptyQueueExceptionInteger() {
        assertThrows(QueueException.class, () -> {
            integerQueue.dequeue();
        }, "Debería lanzar QueueException en cola vacía");

        assertThrows(QueueException.class, () -> {
            integerQueue.peek();
        }, "Debería lanzar QueueException al hacer peek en cola vacía");
    }

    /**
     * Prueba excepción por cola vacía (String)
     */
    @Test
    public void testEmptyQueueExceptionString() {
        assertThrows(QueueException.class, () -> {
            stringQueue.dequeue();
        }, "Debería lanzar QueueException en cola vacía");

        assertThrows(QueueException.class, () -> {
            stringQueue.peek();
        }, "Debería lanzar QueueException al hacer peek en cola vacía");
    }

    /**
     * Prueba excepción por cola llena (Integer)
     */
    @Test
    public void testFullQueueExceptionInteger() throws QueueException {
        // Llenar la cola
        for (int i = 0; i < 5; i++) {
            integerQueue.enqueue(i);
        }

        // Intentar agregar uno más
        assertThrows(QueueException.class, () -> {
            integerQueue.enqueue(5);
        }, "Debería lanzar QueueException cuando la cola está llena");
    }

    /**
     * Prueba excepción por cola llena (String)
     */
    @Test
    public void testFullQueueExceptionString() throws QueueException {
        // Llenar la cola
        for (int i = 0; i < 5; i++) {
            stringQueue.enqueue("Elemento" + i);
        }

        // Intentar agregar uno más
        assertThrows(QueueException.class, () -> {
            stringQueue.enqueue("Extra");
        }, "Debería lanzar QueueException cuando la cola está llena");
    }

    /**
     * Prueba comportamiento FIFO
     */
    @Test
    public void testFIFOBehavior() throws QueueException {
        integerQueue.enqueue(1);
        integerQueue.enqueue(2);
        integerQueue.enqueue(3);

        assertEquals(1, integerQueue.dequeue());
        assertEquals(2, integerQueue.dequeue());
        assertEquals(3, integerQueue.dequeue());
        assertTrue(integerQueue.isEmpty());
    }

    /**
     * Prueba peek sin modificar la cola
     */
    @Test
    public void testPeekDoesNotModify() throws QueueException {
        integerQueue.enqueue(42);

        assertEquals(42, integerQueue.peek());
        assertEquals(1, integerQueue.size());
        assertEquals(42, integerQueue.peek());
    }

    /**
     * Prueba clear
     */
    @Test
    public void testClear() throws QueueException {
        integerQueue.enqueue(1);
        integerQueue.enqueue(2);
        integerQueue.enqueue(3);

        assertFalse(integerQueue.isEmpty());
        integerQueue.clear();
        assertTrue(integerQueue.isEmpty());
        assertEquals(0, integerQueue.size());
    }

    /**
     * Prueba workflow completo Integer
     */
    @Test
    public void testCompleteIntegerWorkflow() throws QueueException {
        // a) Crear cola vacía
        ArrayListQueue<Integer> cola = new ArrayListQueue<>(5);
        assertTrue(cola.isEmpty());

        // b) Agregar entero
        cola.enqueue(42);
        assertFalse(cola.isEmpty());

        // c) Extraer entero
        Integer extracted = cola.dequeue();
        assertEquals(42, extracted);
        assertTrue(cola.isEmpty());

        // d) Excepción cola vacía
        assertThrows(QueueException.class, () -> cola.dequeue());

        // e) Excepción cola llena
        for (int i = 0; i < 5; i++) {
            cola.enqueue(i);
        }
        assertThrows(QueueException.class, () -> cola.enqueue(99));
    }

    /**
     * Prueba workflow completo String
     */
    @Test
    public void testCompleteStringWorkflow() throws QueueException {
        // f) Crear cola vacía
        ArrayListQueue<String> cola = new ArrayListQueue<>(5);
        assertTrue(cola.isEmpty());

        // g) Agregar cadena
        cola.enqueue("Hola");
        assertFalse(cola.isEmpty());

        // h) Extraer cadena
        String extracted = cola.dequeue();
        assertEquals("Hola", extracted);
        assertTrue(cola.isEmpty());

        // i) Excepción cola vacía
        assertThrows(QueueException.class, () -> cola.dequeue());

        // j) Excepción cola llena
        for (int i = 0; i < 5; i++) {
            cola.enqueue("Item" + i);
        }
        assertThrows(QueueException.class, () -> cola.enqueue("Extra"));
    }

    /**
     * Prueba múltiples operaciones enqueue/dequeue
     */
    @Test
    public void testMultipleOperations() throws QueueException {
        integerQueue.enqueue(1);
        integerQueue.enqueue(2);
        assertEquals(1, integerQueue.dequeue());

        integerQueue.enqueue(3);
        integerQueue.enqueue(4);
        assertEquals(2, integerQueue.dequeue());
        assertEquals(3, integerQueue.dequeue());

        integerQueue.enqueue(5);
        assertEquals(4, integerQueue.dequeue());
        assertEquals(5, integerQueue.dequeue());
        assertTrue(integerQueue.isEmpty());
    }
}
