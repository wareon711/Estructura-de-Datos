package implementaciones;

import interfaces.IQueue;
import excepciones.QueueException;
import excepciones.ListException;

/**
 * Archivo: ArrayListQueue.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Implementacion de una cola (Queue) basada en ArrayList
 *
 * Esta clase implementa una cola con comportamiento FIFO (First In, First Out)
 * utilizando ArrayList como estructura de datos subyacente. Los elementos se
 * agregan al final y se extraen desde el inicio de la lista.
 */
public class ArrayListQueue<T> extends ArrayList<T> implements IQueue<T> {

    /**
     * Constructor que crea una cola vacía con la capacidad especificada
     * @param capacity La capacidad máxima de la cola
     */
    public ArrayListQueue(int capacity) {
        super(capacity);
    }

    /**
     * Agrega un elemento al final de la cola
     * @param element El elemento a agregar
     * @throws QueueException si la cola esta llena
     */
    @Override
    public void enqueue(T element) throws QueueException {
        try {
            // Agregar al final de la lista (final de la cola)
            add(element);
        } catch (ListException e) {
            throw new QueueException("La cola esta llena", e);
        }
    }

    /**
     * Extrae y retorna el elemento al frente de la cola
     * @return El elemento que estaba al frente
     * @throws QueueException si la cola esta vacia
     */
    @Override
    public T dequeue() throws QueueException {
        if (isEmpty()) {
            throw new QueueException("La cola esta vacia");
        }

        try {
            // Remover el primer elemento (frente de la cola)
            return remove(0);
        } catch (ListException e) {
            throw new QueueException("Error al extraer elemento de la cola", e);
        }
    }

    /**
     * Retorna el elemento al frente de la cola sin extraerlo
     * @return El elemento al frente
     * @throws QueueException si la cola esta vacia
     */
    @Override
    public T peek() throws QueueException {
        if (isEmpty()) {
            throw new QueueException("La cola esta vacia");
        }

        try {
            // Obtener el primer elemento sin removerlo
            return get(0);
        } catch (ListException e) {
            throw new QueueException("Error al consultar el frente de la cola", e);
        }
    }

    /**
     * Representación en cadena de la cola
     * Muestra los elementos desde el frente hasta el final
     * @return Una representación en cadena de la cola
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "Cola[]";
        }
        return "Cola[frente → " + super.toString().substring(1, super.toString().length() - 1) + " ← final]";
    }
}
