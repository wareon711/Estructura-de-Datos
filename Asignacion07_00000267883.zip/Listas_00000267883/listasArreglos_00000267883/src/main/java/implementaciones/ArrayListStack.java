package implementaciones;

import interfaces.IStack;
import excepciones.StackException;
import excepciones.ListException;

/**
 * Archivo: ArrayListStack.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Implementacion de una pila (Stack) basada en ArrayList
 *
 * Esta clase implementa una pila con comportamiento LIFO (Last In, First Out)
 * utilizando ArrayList como estructura de datos subyacente. Los elementos se
 * agregan y extraen desde el final de la lista.
 */
public class ArrayListStack<T> extends ArrayList<T> implements IStack<T> {

    /**
     * Constructor que crea una pila vacía con la capacidad especificada
     * @param capacity La capacidad máxima de la pila
     */
    public ArrayListStack(int capacity) {
        super(capacity);
    }

    /**
     * Agrega un elemento en la cima de la pila
     * @param element El elemento a agregar
     * @throws StackException si la pila está llena
     */
    @Override
    public void push(T element) throws StackException {
        try {
            // Agregar al final de la lista (cima de la pila)
            add(element);
        } catch (ListException e) {
            throw new StackException("La pila esta llena", e);
        }
    }

    /**
     * Extrae y retorna el elemento en la cima de la pila
     * @return El elemento que estaba en la cima
     * @throws StackException si la pila está vacía
     */
    @Override
    public T pop() throws StackException {
        if (isEmpty()) {
            throw new StackException("La pila esta vacia");
        }

        try {
            // Remover el último elemento (cima de la pila)
            return remove(size() - 1);
        } catch (ListException e) {
            throw new StackException("Error al extraer elemento de la pila", e);
        }
    }

    /**
     * Retorna el elemento en la cima de la pila sin extraerlo
     * @return El elemento en la cima
     * @throws StackException si la pila está vacía
     */
    @Override
    public T peek() throws StackException {
        if (isEmpty()) {
            throw new StackException("La pila esta vacia");
        }

        try {
            // Obtener el último elemento sin removerlo
            return get(size() - 1);
        } catch (ListException e) {
            throw new StackException("Error al consultar la cima de la pila", e);
        }
    }

    /**
     * Representación en cadena de la pila
     * Muestra los elementos desde la base hasta la cima
     * @return Una representación en cadena de la pila
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "Pila[]";
        }
        return "Pila" + super.toString() + " ← cima";
    }
}
