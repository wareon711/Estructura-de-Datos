package demo;

import implementaciones.ArrayListQueue;
import implementaciones.LinkedListQueue;
import excepciones.QueueException;

/**
 * Archivo: DemoQueues.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Clase de demostracion para mostrar el funcionamiento de las colas
 *
 * Esta clase demuestra el uso completo de ArrayListQueue y LinkedListQueue
 * cumpliendo con todos los criterios de corrida especificados en la rubrica.
 */
public class DemoQueues {

    public static void main(String[] args) {
        System.out.println("=== DEMOSTRACION DE COLAS (QUEUES) ===\n");

        demoArrayListQueueInteger();
        System.out.println("\n" + "=".repeat(60) + "\n");

        demoArrayListQueueString();
        System.out.println("\n" + "=".repeat(60) + "\n");

        demoLinkedListQueueInteger();
        System.out.println("\n" + "=".repeat(60) + "\n");

        demoLinkedListQueueString();

        System.out.println("\n=== FIN DE LA DEMOSTRACION ===");
    }

    /**
     * Demostracion de ArrayListQueue con Integer
     * Criterios: a, b, c, d, e
     */
    private static void demoArrayListQueueInteger() {
        System.out.println("DEMOSTRACION: ArrayListQueue<Integer>");
        System.out.println("--------------------------------------");

        try {
            // a) Crear instancia ArrayListQueue de tamanio 5 de tipo Integer, vacia
            ArrayListQueue<Integer> cola = new ArrayListQueue<>(5);
            System.out.println("a) ArrayListQueue<Integer> creada con capacidad 5");
            System.out.println("   Cola vacia: " + cola.isEmpty());
            System.out.println("   Tamanio: " + cola.size());
            System.out.println("   " + cola);

            // b) Agregar un entero a la cola
            System.out.println("\nb) Agregando enteros a la cola...");
            cola.enqueue(10);
            System.out.println("   Enqueue(10): " + cola);
            cola.enqueue(20);
            System.out.println("   Enqueue(20): " + cola);
            cola.enqueue(30);
            System.out.println("   Enqueue(30): " + cola);
            System.out.println("   Tamanio: " + cola.size());

            // c) Extraer un entero de la cola
            System.out.println("\nc) Extrayendo enteros de la cola...");
            Integer extraido = cola.dequeue();
            System.out.println("   Dequeue(): " + extraido);
            System.out.println("   Cola despues: " + cola);
            System.out.println("   Tamanio: " + cola.size());

            extraido = cola.dequeue();
            System.out.println("   Dequeue(): " + extraido);
            System.out.println("   Cola despues: " + cola);

            // d) Lanzar excepcion por cola vacia
            System.out.println("\nd) Probando excepcion por cola vacia...");
            cola.dequeue(); // Extraer el ultimo elemento
            System.out.println("   Cola vacia: " + cola.isEmpty());

            try {
                cola.dequeue(); // Intentar extraer de cola vacia
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

            // e) Lanzar excepcion por cola llena
            System.out.println("\ne) Probando excepcion por cola llena...");
            for (int i = 1; i <= 5; i++) {
                cola.enqueue(i * 10);
                System.out.println("   Enqueue(" + (i * 10) + "): " + cola);
            }

            try {
                cola.enqueue(999); // Intentar agregar a cola llena
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

        } catch (QueueException e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Demostracion de ArrayListQueue con String
     * Criterios: f, g, h, i, j
     */
    private static void demoArrayListQueueString() {
        System.out.println("DEMOSTRACION: ArrayListQueue<String>");
        System.out.println("-------------------------------------");

        try {
            // f) Crear instancia ArrayListQueue de tamanio 5 de tipo String, vacia
            ArrayListQueue<String> cola = new ArrayListQueue<>(5);
            System.out.println("f) ArrayListQueue<String> creada con capacidad 5");
            System.out.println("   Cola vacia: " + cola.isEmpty());
            System.out.println("   Tamanio: " + cola.size());
            System.out.println("   " + cola);

            // g) Agregar una cadena a la cola
            System.out.println("\ng) Agregando cadenas a la cola...");
            cola.enqueue("Primero");
            System.out.println("   Enqueue(\"Primero\"): " + cola);
            cola.enqueue("Segundo");
            System.out.println("   Enqueue(\"Segundo\"): " + cola);
            cola.enqueue("Tercero");
            System.out.println("   Enqueue(\"Tercero\"): " + cola);
            System.out.println("   Tamanio: " + cola.size());

            // h) Extraer una cadena de la cola
            System.out.println("\nh) Extrayendo cadenas de la cola...");
            String extraida = cola.dequeue();
            System.out.println("   Dequeue(): \"" + extraida + "\"");
            System.out.println("   Cola despues: " + cola);
            System.out.println("   Tamanio: " + cola.size());

            extraida = cola.dequeue();
            System.out.println("   Dequeue(): \"" + extraida + "\"");
            System.out.println("   Cola despues: " + cola);

            // i) Lanzar excepcion por cola vacia
            System.out.println("\ni) Probando excepcion por cola vacia...");
            cola.dequeue(); // Extraer el ultimo elemento
            System.out.println("   Cola vacia: " + cola.isEmpty());

            try {
                cola.dequeue(); // Intentar extraer de cola vacia
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

            // j) Lanzar excepcion por cola llena
            System.out.println("\nj) Probando excepcion por cola llena...");
            String[] elementos = {"Uno", "Dos", "Tres", "Cuatro", "Cinco"};
            for (String elemento : elementos) {
                cola.enqueue(elemento);
                System.out.println("   Enqueue(\"" + elemento + "\"): " + cola);
            }

            try {
                cola.enqueue("Extra"); // Intentar agregar a cola llena
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

        } catch (QueueException e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Demostracion de LinkedListQueue con Integer
     * Criterios: k, l, m, n, o
     */
    private static void demoLinkedListQueueInteger() {
        System.out.println("DEMOSTRACION: LinkedListQueue<Integer>");
        System.out.println("---------------------------------------");

        try {
            // k) Crear instancia LinkedListQueue de tipo Integer, vacia
            LinkedListQueue<Integer> cola = new LinkedListQueue<>(5);
            System.out.println("k) LinkedListQueue<Integer> creada con capacidad 5");
            System.out.println("   Cola vacia: " + cola.isEmpty());
            System.out.println("   Tamanio: " + cola.size());
            System.out.println("   " + cola);

            // l) Agregar un entero a la cola
            System.out.println("\nl) Agregando enteros a la cola...");
            cola.enqueue(100);
            System.out.println("   Enqueue(100): " + cola);
            cola.enqueue(200);
            System.out.println("   Enqueue(200): " + cola);
            cola.enqueue(300);
            System.out.println("   Enqueue(300): " + cola);
            System.out.println("   Tamanio: " + cola.size());

            // m) Extraer un entero de la cola
            System.out.println("\nm) Extrayendo enteros de la cola...");
            Integer extraido = cola.dequeue();
            System.out.println("   Dequeue(): " + extraido);
            System.out.println("   Cola despues: " + cola);
            System.out.println("   Tamanio: " + cola.size());

            extraido = cola.dequeue();
            System.out.println("   Dequeue(): " + extraido);
            System.out.println("   Cola despues: " + cola);

            // n) Lanzar excepcion por cola vacia
            System.out.println("\nn) Probando excepcion por cola vacia...");
            cola.dequeue(); // Extraer el ultimo elemento
            System.out.println("   Cola vacia: " + cola.isEmpty());

            try {
                cola.dequeue(); // Intentar extraer de cola vacia
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

            // o) Lanzar excepcion por cola llena
            System.out.println("\no) Probando excepcion por cola llena...");
            for (int i = 1; i <= 5; i++) {
                cola.enqueue(i * 100);
                System.out.println("   Enqueue(" + (i * 100) + "): " + cola);
            }

            try {
                cola.enqueue(999); // Intentar agregar a cola llena
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

        } catch (QueueException e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Demostracion de LinkedListQueue con String
     * Criterios: p, q, r, s, t
     */
    private static void demoLinkedListQueueString() {
        System.out.println("DEMOSTRACION: LinkedListQueue<String>");
        System.out.println("--------------------------------------");

        try {
            // p) Crear instancia LinkedListQueue de tipo String, vacia
            LinkedListQueue<String> cola = new LinkedListQueue<>(5);
            System.out.println("p) LinkedListQueue<String> creada con capacidad 5");
            System.out.println("   Cola vacia: " + cola.isEmpty());
            System.out.println("   Tamanio: " + cola.size());
            System.out.println("   " + cola);

            // q) Agregar una cadena a la cola
            System.out.println("\nq) Agregando cadenas a la cola...");
            cola.enqueue("Java");
            System.out.println("   Enqueue(\"Java\"): " + cola);
            cola.enqueue("Python");
            System.out.println("   Enqueue(\"Python\"): " + cola);
            cola.enqueue("C++");
            System.out.println("   Enqueue(\"C++\"): " + cola);
            System.out.println("   Tamanio: " + cola.size());

            // r) Extraer una cadena de la cola
            System.out.println("\nr) Extrayendo cadenas de la cola...");
            String extraida = cola.dequeue();
            System.out.println("   Dequeue(): \"" + extraida + "\"");
            System.out.println("   Cola despues: " + cola);
            System.out.println("   Tamanio: " + cola.size());

            extraida = cola.dequeue();
            System.out.println("   Dequeue(): \"" + extraida + "\"");
            System.out.println("   Cola despues: " + cola);

            // s) Lanzar excepcion por cola vacia
            System.out.println("\ns) Probando excepcion por cola vacia...");
            cola.dequeue(); // Extraer el ultimo elemento
            System.out.println("   Cola vacia: " + cola.isEmpty());

            try {
                cola.dequeue(); // Intentar extraer de cola vacia
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

            // t) Lanzar excepcion por cola llena
            System.out.println("\nt) Probando excepcion por cola llena...");
            String[] lenguajes = {"Ruby", "Go", "Rust", "Swift", "Kotlin"};
            for (String lenguaje : lenguajes) {
                cola.enqueue(lenguaje);
                System.out.println("   Enqueue(\"" + lenguaje + "\"): " + cola);
            }

            try {
                cola.enqueue("Extra"); // Intentar agregar a cola llena
                System.out.println("   ERROR: No se lanzo excepcion!");
            } catch (QueueException e) {
                System.out.println("   [OK] Excepcion capturada: " + e.getMessage());
            }

        } catch (QueueException e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }
}
