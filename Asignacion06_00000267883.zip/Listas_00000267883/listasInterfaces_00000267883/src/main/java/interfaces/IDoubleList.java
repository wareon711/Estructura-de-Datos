package interfaces;

import excepciones.ListException;

/**
 * Archivo: IDoubleList.java
 * Propósito: Interfaz genérica que define las operaciones de una lista doblemente enlazada
 *
 * Esta interfaz extiende IList y agrega métodos específicos para listas doblemente enlazadas,
 * como la búsqueda del último índice y eliminación de la última ocurrencia.
 */
public interface IDoubleList<T> extends IList<T> {

    /**
     * Obtiene el índice de la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a buscar
     * @return El índice de la última ocurrencia del elemento o -1 si no se encuentra
     */
    int lastIndexOf(T o);

    /**
     * Elimina la última ocurrencia del elemento especificado
     * Busca desde el final de la lista hacia el inicio
     * @param o El elemento a eliminar
     * @return true si el elemento fue encontrado y eliminado, false en caso contrario
     * @throws ListException si la lista está vacía
     */
    boolean removeLast(T o) throws ListException;
}
