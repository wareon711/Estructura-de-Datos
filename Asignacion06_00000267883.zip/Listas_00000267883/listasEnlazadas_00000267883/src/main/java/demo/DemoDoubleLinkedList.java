package demo;

import implementaciones.DoubleLinkedList;
import excepciones.ListException;

/**
 * Archivo: DemoDoubleLinkedList.java
 * Creado por: Gibran Alonso Ibarra Palomares, Jose Miguel Rojo Cota, Karely A. Ruiz Cordova
 * Proposito: Clase de demostracion para mostrar el funcionamiento de DoubleLinkedList
 *
 * Esta clase demuestra el uso completo de la implementacion DoubleLinkedList
 * cumpliendo con todos los criterios de corrida especificados en la rubrica.
 */
public class DemoDoubleLinkedList {

    /**
     * Método principal que ejecuta la demostración
     * @param args Argumentos de línea de comandos
     */
    public static void main(String[] args) {
        System.out.println("=== DEMOSTRACION DE DOUBLELINKEDLIST ===\n");

        // Demostracion con Integer
        demostracionInteger();

        System.out.println("\n" + "=".repeat(50) + "\n");

        // Demostracion con String
        demostracionString();

        System.out.println("\n=== FIN DE LA DEMOSTRACION ===");
    }

    /**
     * Demuestra el uso de DoubleLinkedList con tipo Integer
     * Cumple con los criterios a-f de la rubrica de corrida
     */
    private static void demostracionInteger() {
        try {
            System.out.println("DEMOSTRACION CON TIPO INTEGER:");
            System.out.println("------------------------------");

            // a) Se crea instancia de la clase DoubleLinkedList de tamano 5 de tipo Integer, vacia
            DoubleLinkedList<Integer> listaEnteros = new DoubleLinkedList<>(5);
            System.out.println("a) DoubleLinkedList<Integer> creada con capacidad 5");
            System.out.println("   Lista vacia: " + listaEnteros.isEmpty());
            System.out.println("   Tamano: " + listaEnteros.size());
            System.out.println("   Capacidad: " + listaEnteros.getCapacity());
            System.out.println("   Contenido: " + listaEnteros);

            // b) Agrega un entero a la lista
            Integer entero = 42;
            listaEnteros.add(entero);
            System.out.println("\nb) Entero agregado: " + entero);
            System.out.println("   Lista vacia: " + listaEnteros.isEmpty());
            System.out.println("   Tamano: " + listaEnteros.size());
            System.out.println("   Contenido: " + listaEnteros);

            // Agregar mas elementos incluyendo duplicados
            listaEnteros.add(15);
            listaEnteros.add(entero); // Primer duplicado
            listaEnteros.add(73);
            listaEnteros.add(entero); // Segundo duplicado
            System.out.println("   Agregando mas elementos: 15, 42, 73, 42");
            System.out.println("   Contenido: " + listaEnteros);
            System.out.println("   Contenido inverso: " + listaEnteros.toStringReverse());

            // c) Obtiene el indice de la primera ocurrencia de un entero
            int indice = listaEnteros.indexOf(entero);
            System.out.println("\nc) Indice de la PRIMERA ocurrencia de " + entero + ": " + indice);

            int indiceNoExistente = listaEnteros.indexOf(999);
            System.out.println("   Indice de elemento no existente (999): " + indiceNoExistente);

            // d) Obtiene el indice de la ultima ocurrencia de un entero
            int ultimoIndice = listaEnteros.lastIndexOf(entero);
            System.out.println("\nd) Indice de la ULTIMA ocurrencia de " + entero + ": " + ultimoIndice);
            System.out.println("   Primera ocurrencia en: " + indice + ", ultima en: " + ultimoIndice);

            int ultimoIndiceNoExistente = listaEnteros.lastIndexOf(999);
            System.out.println("   Ultimo indice de elemento no existente (999): " + ultimoIndiceNoExistente);

            // e) Elimina la primera ocurrencia de un entero
            System.out.println("\ne) Eliminando PRIMERA ocurrencia de " + entero);
            System.out.println("   Contenido antes: " + listaEnteros);
            boolean eliminado = listaEnteros.remove(entero);
            System.out.println("   Eliminado exitosamente: " + eliminado);
            System.out.println("   Tamano despues: " + listaEnteros.size());
            System.out.println("   Contenido despues: " + listaEnteros);

            // Verificar nueva primera ocurrencia
            int nuevoIndice = listaEnteros.indexOf(entero);
            System.out.println("   Nueva primera ocurrencia de " + entero + " en indice: " + nuevoIndice);

            // f) Elimina la ultima ocurrencia de un entero
            System.out.println("\nf) Eliminando ULTIMA ocurrencia de " + entero);
            System.out.println("   Contenido antes: " + listaEnteros);
            boolean eliminadoUltimo = listaEnteros.removeLast(entero);
            System.out.println("   Eliminado exitosamente: " + eliminadoUltimo);
            System.out.println("   Tamano despues: " + listaEnteros.size());
            System.out.println("   Contenido despues: " + listaEnteros);

            // Verificar que ya no hay mas ocurrencias
            int indiceRestante = listaEnteros.indexOf(entero);
            System.out.println("   Indice de " + entero + " ahora: " + indiceRestante);

            // Demostrar otros metodos
            System.out.println("\n   METODOS ADICIONALES:");
            listaEnteros.set(100, 0);
            System.out.println("   Despues de set(100, 0): " + listaEnteros);
            System.out.println("   Orden inverso: " + listaEnteros.toStringReverse());

        } catch (ListException e) {
            System.err.println("Error en demostracion Integer: " + e.getMessage());
        }
    }

    /**
     * Demuestra el uso de DoubleLinkedList con tipo String
     * Cumple con los criterios g-l de la rubrica de corrida
     */
    private static void demostracionString() {
        try {
            System.out.println("DEMOSTRACION CON TIPO STRING:");
            System.out.println("-----------------------------");

            // g) Se crea instancia de la clase DoubleLinkedList de tamano 5 de tipo String, vacia
            DoubleLinkedList<String> listaCadenas = new DoubleLinkedList<>(5);
            System.out.println("g) DoubleLinkedList<String> creada con capacidad 5");
            System.out.println("   Lista vacia: " + listaCadenas.isEmpty());
            System.out.println("   Tamano: " + listaCadenas.size());
            System.out.println("   Capacidad: " + listaCadenas.getCapacity());
            System.out.println("   Contenido: " + listaCadenas);

            // h) Agrega una cadena a la lista
            String cadena = "Java";
            listaCadenas.add(cadena);
            System.out.println("\nh) Cadena agregada: \"" + cadena + "\"");
            System.out.println("   Lista vacia: " + listaCadenas.isEmpty());
            System.out.println("   Tamano: " + listaCadenas.size());
            System.out.println("   Contenido: " + listaCadenas);

            // Agregar mas elementos incluyendo duplicados
            listaCadenas.add("Python");
            listaCadenas.add(cadena); // Primer duplicado
            listaCadenas.add("C++");
            listaCadenas.add(cadena); // Segundo duplicado
            System.out.println("   Agregando mas elementos: \"Python\", \"Java\", \"C++\", \"Java\"");
            System.out.println("   Contenido: " + listaCadenas);
            System.out.println("   Contenido inverso: " + listaCadenas.toStringReverse());

            // i) Obtiene el indice de la primera ocurrencia de una cadena
            int indice = listaCadenas.indexOf(cadena);
            System.out.println("\ni) Indice de la PRIMERA ocurrencia de \"" + cadena + "\": " + indice);

            int indiceNoExistente = listaCadenas.indexOf("JavaScript");
            System.out.println("   Indice de elemento no existente (\"JavaScript\"): " + indiceNoExistente);

            // j) Obtiene el indice de la ultima ocurrencia de una cadena
            int ultimoIndice = listaCadenas.lastIndexOf(cadena);
            System.out.println("\nj) Indice de la ULTIMA ocurrencia de \"" + cadena + "\": " + ultimoIndice);
            System.out.println("   Primera ocurrencia en: " + indice + ", ultima en: " + ultimoIndice);

            int ultimoIndiceNoExistente = listaCadenas.lastIndexOf("Ruby");
            System.out.println("   Ultimo indice de elemento no existente (\"Ruby\"): " + ultimoIndiceNoExistente);

            // k) Elimina la primera ocurrencia de una cadena
            System.out.println("\nk) Eliminando PRIMERA ocurrencia de \"" + cadena + "\"");
            System.out.println("   Contenido antes: " + listaCadenas);
            boolean eliminado = listaCadenas.remove(cadena);
            System.out.println("   Eliminado exitosamente: " + eliminado);
            System.out.println("   Tamano despues: " + listaCadenas.size());
            System.out.println("   Contenido despues: " + listaCadenas);

            // Verificar nueva primera ocurrencia
            int nuevoIndice = listaCadenas.indexOf(cadena);
            System.out.println("   Nueva primera ocurrencia de \"" + cadena + "\" en indice: " + nuevoIndice);

            // l) Elimina la ultima ocurrencia de una cadena
            System.out.println("\nl) Eliminando ULTIMA ocurrencia de \"" + cadena + "\"");
            System.out.println("   Contenido antes: " + listaCadenas);
            boolean eliminadoUltimo = listaCadenas.removeLast(cadena);
            System.out.println("   Eliminado exitosamente: " + eliminadoUltimo);
            System.out.println("   Tamano despues: " + listaCadenas.size());
            System.out.println("   Contenido despues: " + listaCadenas);

            // Verificar que ya no hay mas ocurrencias
            int indiceRestante = listaCadenas.indexOf(cadena);
            System.out.println("   Indice de \"" + cadena + "\" ahora: " + indiceRestante);

            // Demostrar otros metodos
            System.out.println("\n   METODOS ADICIONALES:");
            listaCadenas.set("Kotlin", 0);
            System.out.println("   Despues de set(\"Kotlin\", 0): " + listaCadenas);
            System.out.println("   Orden inverso: " + listaCadenas.toStringReverse());

            // Demostrar clear()
            System.out.println("\n   LIMPIANDO LA LISTA:");
            listaCadenas.clear();
            System.out.println("   Despues de clear(): " + listaCadenas);
            System.out.println("   Lista vacia: " + listaCadenas.isEmpty());
            System.out.println("   Tamano: " + listaCadenas.size());

        } catch (ListException e) {
            System.err.println("Error en demostracion String: " + e.getMessage());
        }
    }

    /**
     * Metodo adicional para demostrar las ventajas de la lista doblemente enlazada
     */
    private static void demostracionVentajasListaDoblementeEnlazada() {
        try {
            System.out.println("\n=== VENTAJAS DE LA LISTA DOBLEMENTE ENLAZADA ===");

            DoubleLinkedList<String> lista = new DoubleLinkedList<>(10);

            // Agregar elementos
            lista.add("Primero");
            lista.add("Segundo");
            lista.add("Tercero");
            lista.add("Segundo"); // Duplicado
            lista.add("Cuarto");
            lista.add("Segundo"); // Otro duplicado

            System.out.println("Lista creada: " + lista);
            System.out.println("Lista inversa: " + lista.toStringReverse());

            // Busqueda bidireccional
            System.out.println("\nBusqueda bidireccional:");
            System.out.println("Primera ocurrencia de 'Segundo': " + lista.indexOf("Segundo"));
            System.out.println("Ultima ocurrencia de 'Segundo': " + lista.lastIndexOf("Segundo"));

            // Eliminacion bidireccional
            System.out.println("\nEliminacion bidireccional:");
            System.out.println("Antes: " + lista);
            lista.removeLast("Segundo");
            System.out.println("Despues de removeLast('Segundo'): " + lista);

            // La navegacion bidireccional permite acceso optimizado
            System.out.println("\nAcceso optimizado:");
            System.out.println("Tamano actual: " + lista.size());
            System.out.println("Acceso a elementos cercanos al inicio es rapido");
            System.out.println("Acceso a elementos cercanos al final tambien es rapido");

        } catch (ListException e) {
            System.err.println("Error en demostracion de ventajas: " + e.getMessage());
        }
    }
}
